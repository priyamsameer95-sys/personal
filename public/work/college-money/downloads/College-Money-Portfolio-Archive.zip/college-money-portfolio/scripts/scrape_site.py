#!/usr/bin/env python3
"""Archive public College.money HTML, text and image assets; no form submission."""
import concurrent.futures, hashlib, json, re, sys, time, urllib.parse, urllib.request
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://college.money'
START = BASE + '/abroad'
HEADERS = {'User-Agent': 'Mozilla/5.0 CollegeMoneyPortfolioCapture/1.0'}

class PageParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.images=set(); self.links=set(); self.css=set(); self.text=[]; self.skip=0
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag in ('script','style'): self.skip+=1
        if tag in ('img','source'):
            for k in ('src','data-src','srcset','data-srcset'):
                if a.get(k):
                    for v in a[k].split(','): self.images.add(v.strip().split(' ')[0])
        if tag=='a' and a.get('href'): self.links.add(a['href'])
        if tag=='link' and a.get('rel')=='stylesheet' and a.get('href'): self.css.add(a['href'])
        for u in re.findall(r'url\([\"\']?([^\)\"\']+)',a.get('style','')): self.images.add(u)
    def handle_endtag(self, tag):
        if tag in ('script','style'): self.skip=max(0,self.skip-1)
    def handle_data(self, d):
        if not self.skip and d.strip(): self.text.append(d.strip())

def get(url):
    req=urllib.request.Request(url,headers=HEADERS)
    try:
        with urllib.request.urlopen(req,timeout=15) as r: return r.status,r.geturl(),r.headers.get('Content-Type',''),r.read()
    except urllib.error.HTTPError as e: return e.code,url,e.headers.get('Content-Type',''),e.read()

def save_page(route):
    url=BASE+route; slug=route.strip('/') or 'home'
    try:
        status,final,ctype,data=get(url)
        out=ROOT/'source'/(slug+'-original.html'); out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
        html=data.decode('utf-8',errors='replace'); p=PageParser();p.feed(html)
        (ROOT/'source'/(slug+'-text.txt')).write_text('\n'.join(p.text))
        return {'url':url,'final_url':final,'status':status,'content_type':ctype,'bytes':len(data),'html_file':str(out.relative_to(ROOT))},p,html
    except Exception as e: return {'url':url,'error':str(e)},None,''

def media_urls(parser,html,url):
    urls=set(parser.images)
    urls.update(re.findall(r'(?:https?://[^\s\"\'<>\\]+)?/?assets/[^\s\"\'<>\\]+\.(?:webp|png|jpe?g|svg|gif|avif)',html))
    return {urllib.parse.urljoin(url,u) for u in urls if u and not u.startswith(('data:','blob:'))}

def asset(url):
    bits=urllib.parse.urlsplit(url)
    rel=('assets/'+bits.path.lstrip('/').removeprefix('assets/')) if bits.netloc=='college.money' else ('assets/external/'+bits.netloc+'/'+bits.path.lstrip('/'))
    dest=ROOT/rel
    try:
        status,final,ctype,data=get(url)
        row={'url':url,'status':status,'content_type':ctype,'bytes':len(data)}
        if status==200 and ('image' in ctype or bits.path.lower().endswith(('.svg','.webp','.png','.jpg','.jpeg','.gif','.avif'))):
            dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
            row.update(local_path=rel,sha256=hashlib.sha256(data).hexdigest())
        return row
    except Exception as e: return {'url':url,'error':str(e)}

def main():
    ROOT.mkdir(parents=True,exist_ok=True)
    row,p,html=save_page('/abroad')
    if p is None or row.get('status')!=200: raise RuntimeError(row)
    urls=media_urls(p,html,START)
    # Include responsive backgrounds declared in the page's actual stylesheets.
    def style_assets(css):
        u=urllib.parse.urljoin(START,css)
        found=set()
        try:
            s,f,c,b=get(u);text=b.decode('utf-8',errors='replace')
            target=ROOT/'source'/'styles'/Path(urllib.parse.urlsplit(u).path).name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
            for v in re.findall(r'url\([\"\']?([^\)\"\']+)',text):
                v=urllib.parse.urljoin(u,v)
                if urllib.parse.urlsplit(v).path.lower().endswith(('.svg','.webp','.png','.jpg','.jpeg','.gif','.avif')):found.add(v)
        except Exception: pass
        return found
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        for found in pool.map(style_assets,sorted(p.css)):urls.update(found)
    # Retain image URLs from a prior rendered capture as well as the direct HTML.
    rendered=ROOT/'source'/'abroad.html'
    if rendered.exists():
        rp=PageParser();rh=rendered.read_text();rp.feed(rh);urls.update(media_urls(rp,rh,START))
    print('Downloading',len(urls),'original image assets',flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
        assets=list(pool.map(asset,sorted(urls)))
    routes=['/india','/how-it-works','/loan-types','/eligibility-and-documents','/faq','/about','/contact','/emi-calculator','/privacy']
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        pages=[row]+[x[0] for x in pool.map(save_page,routes)]
    manifest={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'source_url':START,'method':'Custom Python urllib scraper','scope':'Public HTML, linked public routes and original image assets. No login or form submission.','pages':pages,'assets':assets}
    (ROOT/'source'/'capture-manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({'images_saved':sum('local_path'in x for x in assets),'image_failures':sum('local_path'not in x for x in assets),'pages':[{'url':x['url'],'status':x.get('status'),'error':x.get('error')}for x in pages]},indent=2))

if __name__=='__main__':main()
