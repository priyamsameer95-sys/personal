from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
from PIL import Image
import html

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT
OUT = ROOT / 'College-Money-Portfolio-Reference.pdf'
W, H = A4
M = 44
CW = W - 2*M
INK = HexColor('#15202f')
MUTED = HexColor('#596577')
BLUE = HexColor('#1967d2')
PALE = HexColor('#eaf2ff')
LINE = HexColor('#dbe2ed')
WARM = HexColor('#f6f8fc')

pdfmetrics.registerFont(TTFont('Inter', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('Inter-Bold', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFontFamily('Inter', normal='Inter', bold='Inter-Bold')
c = canvas.Canvas(str(OUT), pagesize=A4)
c.setTitle('College.money | Portfolio Reference')
c.setAuthor('Prepared for Priyam Sameer')
c.setSubject('Dated public product and workflow evidence, 13 October 2026')

def text(s, x, y, size=10, color=INK, bold=False):
    c.setFillColor(color)
    c.setFont('Inter-Bold' if bold else 'Inter', size)
    c.drawString(x, y, s)

def para(s, x, top, width=CW, size=10, leading=15, color=INK, bold=False):
    style = ParagraphStyle('p', fontName='Inter-Bold' if bold else 'Inter', fontSize=size,
                           leading=leading, textColor=color, spaceAfter=0)
    p = Paragraph(s, style)
    _, h = p.wrap(width, 1000)
    p.drawOn(c, x, top-h)
    return top-h

def line(y):
    c.setStrokeColor(LINE)
    c.setLineWidth(.7)
    c.line(M,y,W-M,y)

def label(s,x,y,color=BLUE):
    text(s.upper(),x,y,8.2,color,True)

def header(n, topic):
    c.setFillColor(white)
    c.rect(0,0,W,H,fill=1,stroke=0)
    c.setFillColor(BLUE)
    c.rect(M,H-48,26,3,fill=1,stroke=0)
    label('COLLEGE.MONEY  /  PORTFOLIO REFERENCE',M,H-66)
    text(topic,M,H-99,25,INK,True)
    line(50)
    text('PUBLIC PRODUCT RECORD  |  13 OCT 2026',M,31,7.1,MUTED)
    c.setFont('Inter-Bold',8)
    c.drawRightString(W-M,31,f'{n:02d} / 04')

def shot(name,x,top,width,height=None,crop=None):
    im=Image.open(PACK/'screenshots'/name).convert('RGB')
    if crop: im=im.crop(crop)
    iw,ih=im.size
    if height is None: height=width*ih/iw
    c.drawImage(ImageReader(im),x,top-height,width=width,height=height)
    c.setStrokeColor(LINE)
    c.roundRect(x,top-height,width,height,5,stroke=1,fill=0)
    return top-height

def card(x,top,width,height,fill=PALE):
    c.setFillColor(fill)
    c.roundRect(x,top-height,width,height,9,fill=1,stroke=0)

# 1: Product and attribution
header(1,'College.money')
para('Education-loan discovery and application support for students planning overseas study.',
     M,H-121,size=12,leading=18,color=MUTED)
bottom=shot('abroad-hero-live.jpg',M,652,CW)
para('LIVE PUBLIC INTERFACE  /  Abroad landing page and initial loan-discovery form.',
     M,bottom-11,size=7.6,leading=11,color=MUTED)
card(M,251,CW,89)
label('PROJECT ATTRIBUTION',M+16,229)
para('Priyam Sameer identifies College.money as his education-loan project in CashKaro\'s production environment. This attribution is user-provided.',
     M+16,214,CW-32,size=10,leading=14)
para('The public footer visibly names CashKaro and Pouring Pounds India Limited.',
     M+16,178,CW-32,size=8.4,leading=12,color=MUTED)
label('AUDIENCE',M,133)
para('Students seeking overseas education financing, with parents or other co-applicants supporting income and collateral requirements.',
     M,119,242,size=9,leading=13)
label('PRODUCT POSITIONING',M+265,133)
para('An education-loan marketplace that compares lenders and describes a guided journey from discovery to disbursement.',
     M+265,119,242,size=9,leading=13)
c.showPage()

# 2: Inspected versus described workflow
header(2,'The visible entry flow')
para('The public form exposes the start of the journey. Later application stages are described by the website and were not inspected behind phone verification.',
     M,H-121,size=10.5,leading=16,color=MUTED)
label('INSPECTED ON THE LIVE PAGE',M,668)
shot('abroad-hero-live.jpg',M,650,192,crop=(774,133,1178,696))
label('INPUTS VISIBLE',M+217,649)
para('Mobile number (+91)<br/>Destination country<br/>University<br/>Residential pincode<br/>Desired loan amount',
     M+217,634,CW-217,size=10,leading=20)
para('The slider showed a ₹40 lakh default, with bounds of ₹10 lakh and ₹2 crore. The CTA reads “See my lender options”.',
     M+217,521,CW-217,size=9.2,leading=14,color=MUTED)
label('SELECTOR OBSERVATIONS',M+217,458)
para('Country selector opened and United States was selected. University options were searchable and loaded after a brief initial empty state, including MIT, Stanford, Harvard and Caltech.',
     M+217,444,CW-217,size=9.2,leading=14)
para('Screenshot: form at entry, before any personal information was submitted.',M,369,192,size=7.6,leading=11,color=MUTED)
line(336)
label('DESCRIBED BY THE WEBSITE  /  NOT END-TO-END TESTED',M,315)
stages=[
    ('01','Course profile','Country, course, intake and estimated cost are documented on /how-it-works.'),
    ('02','Co-applicant profile','The public guide describes collecting income and occupation details.'),
    ('03','Lender options','The guide describes indicative terms. /abroad promotes ranked offers.'),
    ('04','Document upload','The guide describes uploading once for the chosen lender.'),
    ('05','Lender review and funding','The lender reviews documents, confirms final terms and funds after approval.')
]
y=292
for num,title,body in stages:
    text(num,M,y,11,BLUE,True)
    para(title,M+34,y+10,CW-34,size=9.5,leading=13,bold=True)
    para(body,M+34,y-6,CW-34,size=8.5,leading=12,color=MUTED)
    y-=44
c.showPage()

# 3: Capability evidence
header(3,'Product capabilities')
para('The public experience combines comparison, loan education and application preparation. Screens below preserve the presentation used on the live site.',
     M,H-121,size=10.5,leading=16,color=MUTED)
bottom=shot('abroad-how-it-works.jpg',M,664,CW,crop=(145,132,1188,842))
para('LIVE PUBLIC SECTION  /  The site\'s four advertised steps; these cards are explanatory, not evidence of completed applications.',
     M,bottom-10,CW,size=7.5,leading=11,color=MUTED)
label('READINESS GUIDANCE',M,269)
shot('abroad-readiness.jpg',M,253,214,crop=(600,300,1140,652))
para('Admission, identity and income documents are presented as immediate requirements; visa / I-20 is marked for later.',
     M,99,214,size=7.4,leading=10.5,color=MUTED)
label('CAPABILITY EVIDENCE',M+238,269)
para('<b>Loan choice.</b> Separate unsecured and collateral-backed explanations make the financing options easier to distinguish.',
     M+238,253,CW-238,size=9,leading=13)
para('<b>Decision support.</b> Comparison is framed around price, EMI and approval likelihood. Lenders confirm final terms.',
     M+238,194,CW-238,size=9,leading=13)
para('<b>Application readiness.</b> Document timing and an income-to-EMI rule of thumb help users prepare.',
     M+238,147,CW-238,size=9,leading=13)
para('<b>Cost estimation.</b> The public EMI calculator explicitly labels its results as indicative.',
     M+238,101,CW-238,size=8.5,leading=12)
c.showPage()

# 4: Evidence register and future story inputs
header(4,'Evidence and next inputs')
para('This is a dated portfolio reference. It preserves observable screens, user attribution and website claims as separate kinds of evidence.',
     M,H-121,size=10.5,leading=16,color=MUTED)
label('SOURCE RECORD',M,668)
para('<b>Primary page:</b> https://college.money/abroad<br/><b>Additional public sources:</b> /how-it-works, /faq, /eligibility-and-documents and /emi-calculator on college.money.<br/><b>Capture date:</b> 13 October 2026. Public pages and selectors only; no OTP request or application submission.',
     M,652,CW,size=8.6,leading=14)
c.linkURL('https://college.money/abroad',(M,633,M+300,651),relative=0,thickness=0)
label('EVIDENCE REGISTER',M,553)
style=ParagraphStyle('cell',fontName='Inter',fontSize=8.1,leading=11.7,textColor=INK)
style_b=ParagraphStyle('cellb',parent=style,fontName='Inter-Bold')
def cell(s,bold=False): return Paragraph(s,style_b if bold else style)
rows=[
    [cell('Evidence type',True),cell('What can be used',True),cell('Qualification',True)],
    [cell('Inspected interface'),cell('Input form, country selector, loaded university options, public journey and readiness guidance.'),cell('Public UI only. Authenticated application and lender operations were not inspected.')],
    [cell('User attribution'),cell('Priyam\'s education-loan project in CashKaro\'s production environment.'),cell('Provided by Priyam. Specific responsibilities, team and delivery timeline remain to be documented.')],
    [cell('Public association'),cell('CashKaro branding and Pouring Pounds India Limited in the footer.'),cell('Business association is visible. It does not establish individual ownership.')],
    [cell('Page-stated metrics'),cell('₹420 crore+ disbursed; 18 lenders; 92% approval; 4.8-star student rating.'),cell('Unverified marketing claims. No cohort, date range or calculation method was available.')],
    [cell('Described service'),cell('Lender comparison, document reuse, free student service and support through disbursement.'),cell('/abroad promotes real offers; /how-it-works labels terms indicative and /faq requires lender review. Final financial terms were not tested.')]
]
t=Table(rows,colWidths=[105,199,CW-304])
t.setStyle(TableStyle([
    ('BACKGROUND',(0,0),(-1,0),PALE),('VALIGN',(0,0),(-1,-1),'TOP'),
    ('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),
    ('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),
    ('LINEBELOW',(0,0),(-1,-1),.5,LINE)
]))
tw,th=t.wrap(CW,1000)
t.drawOn(c,M,536-th)
next_top=536-th-22
label('TO TURN THIS INTO A FULL CASE STUDY',M,next_top)
para('Add Priyam\'s scope and decision rights; delivery dates and collaborators; the original user problem; alternatives and trade-offs; implementation evidence; and measured outcomes with baseline, period and attribution.',
     M,next_top-14,CW,size=8.8,leading=13)
para('Backend architecture, AI, MCP, lender integrations and impact metrics are not inferred from these screens.',
     M,next_top-66,CW,size=8,leading=12,color=MUTED)
c.showPage()
c.save()
print(OUT)
