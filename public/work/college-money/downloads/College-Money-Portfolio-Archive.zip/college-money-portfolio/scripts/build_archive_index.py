"""Create an offline gallery from the saved capture, without contacting the site."""
from pathlib import Path
import html,json

ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'source/capture-manifest.json').read_text())
def esc(x):return html.escape(str(x))
def item(path,label):
    return f'<figure><a href="{esc(path)}"><img loading="lazy" src="{esc(path)}" alt="{esc(label)}"></a><figcaption>{esc(label)}</figcaption></figure>'
screens=''.join(item(p.relative_to(ROOT),p.stem.replace('-',' '))for p in sorted((ROOT/'screenshots').glob('*')) if p.is_file())
groups={}
for a in manifest['assets']:
    p=a.get('local_path')
    if not p:continue
    parts=Path(p).parts
    group=parts[2] if len(parts)>2 and parts[1]=='images' else parts[1]
    groups.setdefault(group,[]).append(p)
gallery=''.join(f'<details><summary>{esc(k)} ({len(v)})</summary><div class="gallery">'+''.join(item(p,Path(p).name)for p in v)+'</div></details>'for k,v in sorted(groups.items()))
videos=''
if (ROOT/'videos').exists():
    films=sorted((ROOT/'videos').glob('*.mp4'))
    if films:
        videos='<h2>Short portfolio videos</h2><p>Silent 20-second clips made from animated public captures and original site illustrations. These are not live recordings of authenticated application steps.</p><div class="gallery">'+''.join('<figure><video controls preload="metadata" style="width:100%;display:block" src="'+esc(p.relative_to(ROOT))+'"></video><figcaption><a href="'+esc(p.relative_to(ROOT))+'">'+esc(p.stem.replace('-',' '))+'</a></figcaption></figure>'for p in films)+'</div>'
rows=''.join(f'<tr><td><a href="{esc(x["url"])}">{esc(x["url"])}</a></td><td>{x.get("status","error")}</td><td><a href="{esc(x.get("html_file",""))}">HTML</a></td><td><a href="{esc(x.get("html_file","").replace("-original.html","-text.txt"))}">Text</a></td></tr>'for x in manifest['pages'])
readme=esc((ROOT/'README.txt').read_text())
out='''<!DOCTYPE html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>College.money | Portfolio archive</title><style>body{font:16px/1.65 system-ui,sans-serif;color:#172334;background:#f6f9fd;margin:0}main{max-width:1180px;margin:0 auto;padding:48px 24px}h1{font-size:42px;line-height:1.15;margin:8px 0}h2{margin-top:48px}small{color:#627187}.badge{color:#1a63d3;font-size:13px;font-weight:700;letter-spacing:.12em}a{color:#195fbb}section,details{background:white;border:1px solid #dae3ef;border-radius:14px;padding:20px;margin:16px 0}.gallery{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}.screens{grid-template-columns:repeat(auto-fit,minmax(460px,1fr))}figure{margin:0;background:#fff;border:1px solid #e3e9f0;border-radius:12px;overflow:hidden}img{display:block;width:100%;height:220px;object-fit:contain;background:#eef4fa}.screens img{height:330px;object-fit:contain}figcaption{padding:12px;font-size:13px;color:#506078;word-break:break-word}summary{cursor:pointer;font-weight:650}table{width:100%;border-collapse:collapse;font-size:14px}td,th{text-align:left;padding:10px;border-bottom:1px solid #e2e8f0;overflow-wrap:anywhere}pre{white-space:pre-wrap;font:14px/1.7 system-ui,sans-serif}li{margin:8px 0}.flow{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}.flow div{background:#e9f1ff;border-radius:12px;padding:18px}.flow b{display:block;color:#195fbb;margin-bottom:6px}@media(max-width:550px){.screens{grid-template-columns:1fr}h1{font-size:32px}main{padding:28px 16px}}</style><main><div class="badge">PRIYAM SAMEER / PUBLIC PRODUCT RECORD</div><h1>College.money</h1><p>Education-loan discovery, comparison and application support.</p><small>Captured 13 October 2026. Priyam describes this as his project in CashKaro production.</small><section><p><a href="College-Money-Portfolio-Reference.pdf">Open the four-page portfolio reference</a> · <a href="workflow.json">Structured workflow</a> · <a href="README.txt">Notes</a> · <a href="scripts/scrape_site.py">Custom scraper</a></p><p>The visible entry includes phone, destination country, university, residential pincode and loan amount. Authenticated offers, uploads and disbursement were not tested.</p><div class="flow"><div><b>01 Course context</b>Country, course, intake and cost</div><div><b>02 Co-applicant</b>Income and occupation</div><div><b>03 Lender options</b>Indicative comparison</div><div><b>04 Documents</b>Submission to selected lenders</div><div><b>05 Review and funding</b>Lender decision and disbursement</div></div><small>These five stages are described by the public /how-it-works guide.</small></section><h2>Screen captures</h2><div class="gallery screens">'''+screens+'''</div><h2>Original image assets</h2><p>185 preserved originals, including illustrations, lender tiles, backgrounds, logos, icons and flags. Click an image to open its original file.</p>'''+gallery+'''<h2>Public pages</h2><section><table><tr><th>URL</th><th>HTTP</th><th>Source</th><th>Readable copy</th></tr>'''+rows+'''</table></section><h2>Workflow and evidence notes</h2><section><pre>'''+readme+'''</pre></section><p><a href="source/capture-manifest.json">Capture inventory and checksums</a></p></main></html>'''
(ROOT/'index.html').write_text(out.replace('<h2>Screen captures</h2>',videos+'<h2>Screen captures</h2>'))
print('Created offline gallery')
