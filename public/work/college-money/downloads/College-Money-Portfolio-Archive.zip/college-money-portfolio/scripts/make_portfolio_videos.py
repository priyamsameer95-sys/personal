"""Make silent 1080p portfolio clips from archived public captures and site art.

No live screen recording, OTP verification or application submission is implied.
Requires Python 3, Pillow, ffmpeg and the archived screenshots/assets.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
import concurrent.futures, json, math, subprocess

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'videos'
OUT.mkdir(exist_ok=True)
W,H,FPS=1920,1080,24
FONT=Path('/usr/share/fonts/truetype/dejavu')
def font(n,bold=False):return ImageFont.truetype(str(FONT/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')),n)
F44,F22,F54,F27,F19=font(44,True),font(22),font(54,True),font(27),font(19)

S=ROOT/'screenshots'
A=ROOT/'assets/images/how-it-works'
CLIPS=[
 {'file':'College-Money-01-Product-Overview.mp4','title':'PRODUCT OVERVIEW','kind':'Animated public-page screenshots',
  'scenes':[
   {'file':S/'abroad-hero-live.jpg','crop':(0,0,1348,775),'seconds':7,'title':'Education-loan\ndiscovery','detail':'The study-abroad entry point.','label':'Public interface'},
   {'file':S/'abroad-hero-live.jpg','crop':(770,127,1185,700),'seconds':6,'title':'One place to\nstart','detail':'Phone, country, university, pincode and loan amount.','label':'Public entry form'},
   {'file':S/'abroad-readiness.jpg','crop':(140,90,1200,810),'seconds':7,'title':'Prepare for the\napplication','detail':'Student and co-applicant documentation, with a readiness checklist.','label':'Public guidance'}]},
 {'file':'College-Money-02-Loan-Discovery.mp4','title':'LOAN-DISCOVERY ENTRY','kind':'Animated public-page screenshots',
  'scenes':[
   {'file':S/'abroad-hero-live.jpg','crop':(770,127,1185,700),'seconds':4,'title':'Start with\nyour profile','detail':'A visible form before phone verification.','label':'No personal details entered'},
   {'file':S/'abroad-country-selector.jpg','crop':(0,0,1348,750),'seconds':5,'title':'Choose your\ndestination','detail':'Searchable country selection, with prominent study destinations.','label':'Inspected country selector'},
   {'file':S/'abroad-university-options-verified.jpg','crop':(0,0,1348,775),'seconds':5,'title':'Find your\nuniversity','detail':'The university list shown after choosing the United States.','label':'Inspected university list'},
   {'file':S/'abroad-hero-live.jpg','crop':(793,412,1162,681),'seconds':6,'title':'Set your\nloan amount','detail':'Amount controls and the lender-options call to action.','label':'CTA preserved; not submitted'}]},
 {'file':'College-Money-03-Published-Journey.mp4','title':'PUBLISHED APPLICATION JOURNEY','kind':'Journey described by the website',
  'scenes':[
   {'file':A/'step-1.webp','seconds':4,'title':'Share your\nstudy profile','detail':'Course, intake, country and estimated costs.','label':'Original site illustration'},
   {'file':A/'step-2.webp','seconds':4,'title':'Compare\nlender options','detail':'Potential lender paths and indicative terms.','label':'Original site illustration'},
   {'file':A/'step-3.webp','seconds':4,'title':'Upload\ndetails once','detail':'Documents shared with the lenders selected.','label':'Original site illustration'},
   {'file':A/'step-4.webp','seconds':4,'title':'Get guided\nsupport','detail':'Lender review followed by approval and disbursement.','label':'Original site illustration'},
   {'file':S/'abroad-readiness.jpg','crop':(140,90,1200,810),'seconds':4,'title':'Prepare the\ndocuments','detail':'Final terms and approval depend on lender review.','label':'Public readiness checklist'}]}
]

def wrapped(draw,text,face,width):
    lines=[]
    for paragraph in text.split('\n'):
        line=''
        for word in paragraph.split():
            new=(line+' '+word).strip()
            if draw.textlength(new,font=face)>width and line:lines.append(line);line=word
            else:line=new
        lines.append(line)
    return lines

def draw_scene(clip,scene,index,p):
    frame=Image.new('RGB',(W,H),'#0a2033');d=ImageDraw.Draw(frame)
    d.text((54,34),'COLLEGE.MONEY',font=F44,fill='#ffffff')
    d.text((56,92),clip['title'],font=F22,fill='#88bafd')
    d.text((1535,50),'PORTFOLIO / 13 OCT 2026',font=F19,fill='#afc1d5')
    box=(54,146,1360,950);bw,bh=1306,804
    d.rounded_rectangle((46,139,1368,958),radius=17,fill='#19374e')
    d.rounded_rectangle(box,radius=12,fill='#f0f5fb')
    im=scene['_image'];base_scale=min(bw/im.width,bh/im.height)
    ease=(1-math.cos(math.pi*p))/2
    scale=base_scale*(1+.027*ease)
    scaled=im.resize((round(im.width*scale),round(im.height*scale)),Image.Resampling.LANCZOS)
    visual=Image.new('RGB',(bw,bh),'#f0f5fb')
    visual.paste(scaled,((bw-scaled.width)//2,(bh-scaled.height)//2))
    mask=Image.new('L',(bw,bh),0);ImageDraw.Draw(mask).rounded_rectangle((0,0,bw,bh),radius=12,fill=255)
    frame.paste(visual,(54,146),mask)
    d=ImageDraw.Draw(frame)
    d.rounded_rectangle((1420,230,1508,281),radius=13,fill='#1c66b3')
    d.text((1443,238),f'{index+1:02d}',font=font(27,True),fill='white')
    y=318
    for line in wrapped(d,scene['title'],F54,430):d.text((1420,y),line,font=F54,fill='white');y+=68
    y+=28
    for line in wrapped(d,scene['detail'],F27,420):d.text((1420,y),line,font=F27,fill='#bbd0e6');y+=41
    d.line((1420,806,1835,806),fill='#33516e',width=2)
    y=828
    for line in wrapped(d,scene['label'],F22,425):d.text((1420,y),line,font=F22,fill='#87b7f0');y+=31
    footer=clip['kind']+'  |  13 Oct 2026'
    d.text((54,990),footer,font=F19,fill='#a6bed8')
    d.text((1520,990),'college.money/abroad',font=F19,fill='#c5d9ee')
    return frame

def render(clip):
    scenes=clip['scenes'];total=sum(x['seconds'] for x in scenes);dest=OUT/clip['file']
    for s in scenes:
        im=Image.open(s['file']).convert('RGB')
        if s.get('crop'):im=im.crop(s['crop'])
        s['_image']=im
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-threads','3','-movflags','+faststart','-metadata','title=College.money '+clip['title'].title(),'-metadata','comment='+clip['kind']+'; public source captured 13 October 2026; not a live screen recording.',str(dest)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    previous=None;n=0;thumbs=[]
    try:
        for i,s in enumerate(scenes):
            count=round(s['seconds']*FPS)
            for j in range(count):
                frame=draw_scene(clip,s,i,j/max(1,count-1))
                if previous is not None and j<round(.3*FPS):frame=Image.blend(previous,frame,j/round(.3*FPS))
                d=ImageDraw.Draw(frame);d.rounded_rectangle((54,1040,1866,1046),radius=3,fill='#294764');d.rounded_rectangle((54,1040,54+round(1812*(n+1)/(total*FPS)),1046),radius=3,fill='#59a5ff')
                if j==count//2:thumbs.append(frame.resize((640,360),Image.Resampling.LANCZOS))
                proc.stdin.write(frame.tobytes());n+=1
            previous=frame
        proc.stdin.close();rc=proc.wait()
        if rc:raise RuntimeError(f'ffmpeg exited {rc}')
    except Exception:
        proc.kill();raise
    sheet=Image.new('RGB',(640*len(thumbs),360),'white')
    for i,t in enumerate(thumbs):sheet.paste(t,(i*640,0))
    sheet.save(OUT/(dest.stem+'-preview.jpg'),quality=92)
    print(json.dumps({'file':dest.name,'seconds':total,'frames':n,'bytes':dest.stat().st_size}),flush=True)
    return {'file':dest.name,'duration_seconds':total,'width':W,'height':H,'fps':FPS,'audio':False,'source_type':clip['kind'],'scenes':[{'seconds':s['seconds'],'title':s['title'].replace('\n',' '),'source_file':str(s['file'].relative_to(ROOT)),'label':s['label']}for s in scenes]}

if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:records=list(pool.map(render,CLIPS))
    (OUT/'video-manifest.json').write_text(json.dumps({'project':'College.money','capture_date':'2026-10-13','description':'Silent animated public-page captures and original website illustrations. Not live screen recordings; no authenticated application workflow captured.','videos':records},indent=2))
    (OUT/'README.txt').write_text('Three 20-second, silent, 1080p MP4 portfolio clips.\n01 Product overview; 02 Loan-discovery entry; 03 Published application journey.\nCreated from saved public screenshots and original site illustrations captured on 13 October 2026.\nThese are animated portfolio presentations, not recordings of OTP, offer generation, document uploads or an actual submitted application.\nThe third clip explains the journey described by the website.\n')
