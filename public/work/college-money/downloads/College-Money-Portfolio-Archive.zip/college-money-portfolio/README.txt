COLLEGE.MONEY | PORTFOLIO SOURCE ARCHIVE
Captured 13 October 2026 | Priyam Sameer
Source: https://college.money/abroad

PROJECT ATTRIBUTION
Priyam describes College.money as his education-loan project running in CashKaro's production environment. This is user-provided attribution. The public footer independently displays CashKaro and Pouring Pounds India Limited. Individual responsibilities and ownership boundaries have not been verified by this capture.

PURPOSE
Preserve the current public product, original images, screens and student journey as reference material for Priyam's portfolio. This is a dated evidence archive, not a claim that every advertised feature or outcome has been tested.

PRODUCT POSITIONING
An education-loan marketplace helping students discover financing options for overseas study, compare lenders, prepare a reusable application and receive assistance toward disbursement. The website states that it compares lenders rather than lending directly, that students use the service for free, and that lenders pay on successful disbursement.

INSPECTED PUBLIC ENTRY WORKFLOW
1. Open the Abroad landing page. A separate India destination is available.
2. Enter a 10-digit Indian mobile number. The page says a one-time code will be sent for verification; no phone number was entered and no OTP was requested.
3. Search or choose the destination country. The open selector separates top countries from the full list. United States was selected only as an illustrative browsing input.
4. Search or choose a university. The country selection was followed by a university list containing MIT, Stanford, Harvard, Caltech, University of Chicago, University of Pennsylvania, Cornell and UC Berkeley. The list initially showed "No options" before asynchronously loading. A brief Harvard search was explored; no application was created.
5. Provide residential pincode. The field and explanation control are visible; no pincode was entered.
6. Set desired loan amount. The public control displays a default of INR 40 lakh and a range of INR 10 lakh to INR 2 crore. No lender terms were validated.
7. Use the lender-options call to action. It was preserved as a visible affordance, not submitted.

PAGE-DESCRIBED CONTINUATION (NOT AUTHENTICATED OR TESTED)
A. Phone verification using a one-time code.
B. A ranked lender shortlist with rate and EMI comparison; FAQ describes approval odds, rate range and EMI as ranking dimensions.
C. Select lenders, provide details and upload documents once for sharing with selected lenders.
D. Submit the application and receive assistance through disbursement and overseas departure.
The exact ordering of OTP relative to additional profile collection, the authenticated screen sequence, ranking implementation, document-sharing permissions, lender handoff and servicing operations cannot be established from the public page.

SUPPORTING PUBLIC WORKFLOW PAGES
https://college.money/how-it-works describes five stages: course context (country, course, intake and cost), co-applicant income and occupation, indicative lender options, document submission to a selected lender, and lender review followed by approval and fund transfer.
https://college.money/eligibility-and-documents details student identity/academic/admission records, applicable test scores, co-applicant identity/income/bank statements and collateral documents for secured loans.
https://college.money/emi-calculator exposes an indicative repayment estimator. Default public values are INR 20 lakh, 11% annual interest and 10 years, with displayed monthly EMI INR 27,550. The calculation was preserved, not independently audited.
https://college.money/faq clarifies that lenders review information before making an offer. The supporting pages qualify terms as indicative; the Abroad landing page uses stronger marketing language about real rates and EMIs. Preserve this difference rather than treating landing-page copy as confirmed loan offers.
https://college.money/about describes one application, comparison and human support for students and families. Associated internal operations remain outside this public capture.

PUBLIC PAGE SECTIONS PRESERVED
Hero and profile form; country rate teasers; comparison table; marketing statistics; lender logo wall; four-stage journey illustrations; unsecured and collateral-backed loan cards; co-applicant income and document readiness; student-services tiles; testimonials; FAQ; final eligibility CTA and organizational footer.
The adjacent-services section includes a Coming soon label. Do not present all those tiles as shipped services.

EVIDENCE REGISTER
Observed UI: Country selector, country-specific university list, residential pincode field, loan amount controls, public navigation, page sections and lender branding.
Page-described behavior: OTP verification, ranked offers, single upload shared with selected lenders and assistance through disbursement.
User-provided project context: Priyam's project, education loans, CashKaro production environment, intended portfolio use.
Page-stated metrics: INR 420 crore+ disbursed, 18 lenders, 92% approval rate and 4.8-star student rating. No measurement period, cohort or validation is supplied. These are dated website claims, not verified Priyam outcomes.
Visible lender names: SBI, Credila, Bank of India, PNB, ICICI, IDFC First, Axis, Avanse, Canara and Auxilo. A logo does not verify a technical API integration, contractual partnership or live product availability.
Unverified: MCP/AI implementation, APIs and normalized contracts, underwriting logic, counselor/CRM tools, transaction volumes, conversion lift, user research, delivery timeline, team and individual contribution.
Loan rates, limits and turnaround statements are marketing copy preserved for fidelity; they are not validated financial advice or guaranteed terms.

HOW TO USE THIS ARCHIVE
Open index.html after extracting the ZIP to browse the screen and original-image galleries without needing the live website.
screenshots/ contains public product captures; assets/ contains original raster and vector files.
source/ contains captured HTML, extracted page text, styles, route inventory and download checksums/statuses.
workflow.json contains the structured public journey with source and evidence labels for later reuse.
videos/ contains three silent 20-second 1080p MP4 portfolio clips: product overview, loan-discovery entry and the published application journey. The clips animate the archived screenshots and original site illustrations. They are not live screen recordings and do not demonstrate OTP, generated offers, document upload or a submitted application. Evidence labels remain visible in each clip.
scripts/scrape_site.py is the reusable custom scraper requested by Priyam. Run with Python 3 to refresh public HTML and original images. It never submits forms or logs in. Browser screenshots require a separate visual capture.
The saved HTML is a source record, not a guaranteed functional offline copy of the application. Use the screenshot gallery for faithful visual reference.

INPUTS TO ADD BEFORE WRITING THE FINAL CASE STUDY
Define Priyam's actual role, dates and team; the starting student/operations problem; key product decisions and trade-offs; dependencies and lender integrations he owned; rollout stages; measured outcomes and their time windows; and artifacts supporting those claims. Authenticated offers, document uploads and counselor/admin workflow screenshots can extend this public archive when provided through an authorized test/demo environment.
