Three 20-second, silent, 1080p MP4 portfolio clips.
01 Product overview; 02 Loan-discovery entry; 03 Published application journey.
Created from saved public screenshots and original site illustrations captured on 13 October 2026.
These are animated portfolio presentations, not recordings of OTP, offer generation, document uploads or an actual submitted application.
The third clip explains the journey described by the website.
