#!/usr/bin/env python3
"""Download original public image URLs explicitly exported from rendered Upaj pages.

This script consumes the three *-rendered-metadata.json files. It does not crawl
routes, execute JavaScript, submit forms, or infer undisclosed asset endpoints.
Python's standard library handles HTTP/downloads. Pillow verifies raster files.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import io
import json
import mimetypes
from pathlib import Path
import re
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urljoin, urlsplit, urlunsplit
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

PRODUCTS = ("riskstac", "finstac", "growstac")
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".avif", ".ico", ".bmp", ".tif", ".tiff"}


def normalize_url(value: str, base_url: str) -> str | None:
    value = value.strip()
    if not value or value.startswith(("data:", "blob:", "javascript:")):
        return None
    parsed = urlsplit(urljoin(base_url, value))
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return None
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, parsed.query, ""))


def explicit_image_urls(metadata: dict, base_url: str) -> set[str]:
    """Accept concrete exported image/background URL strings and common objects."""
    found: set[str] = set()

    def accept(value):
        if isinstance(value, str):
            css = re.findall(r"url\(\s*['\"]?([^'\")]+)", value)
            candidates = css if css else [value]
            for candidate in candidates:
                normalized = normalize_url(candidate, base_url)
                if normalized:
                    found.add(normalized)
        elif isinstance(value, list):
            for item in value:
                accept(item)
        elif isinstance(value, dict):
            for key in ("src", "url", "currentSrc", "background", "backgroundImage", "urls"):
                if key in value:
                    accept(value[key])
            # Browser-exported srcset is a list, or the actual DOM string.
            srcset = value.get("srcset") or value.get("srcSet")
            if isinstance(srcset, str):
                for item in srcset.split(","):
                    accept(item.strip().split(" ", 1)[0])
            elif srcset:
                accept(srcset)

    for key in ("images", "backgrounds", "backgroundImages", "background_urls", "image_urls"):
        accept(metadata.get(key, []))
    # Already-observed links directly to images are public assets, not new routes.
    for link in metadata.get("links", []):
        value = link.get("href") or link.get("url", "") if isinstance(link, dict) else link
        if isinstance(value, str) and Path(urlsplit(value).path).suffix.lower() in IMAGE_EXTENSIONS:
            accept(value)
    return found


def safe_part(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9._-]", "_", value) or "asset"


def asset_relative_path(url: str, content_type: str, data: bytes) -> Path:
    parsed = urlsplit(url)
    segments = [safe_part(unquote(segment)) for segment in parsed.path.split("/") if segment]
    if not segments:
        segments = ["asset"]
    name = segments[-1]
    suffix = Path(name).suffix.lower()
    if suffix not in IMAGE_EXTENSIONS:
        guessed = ".svg" if b"<svg" in data[:1000].lower() else (mimetypes.guess_extension(content_type) or ".img")
        name += guessed
    if parsed.query:
        path = Path(name)
        name = path.stem + "-" + hashlib.sha256(parsed.query.encode()).hexdigest()[:10] + path.suffix
    segments[-1] = name
    return Path(safe_part(parsed.netloc), *segments)


def verify_image(data: bytes, content_type: str) -> dict:
    if "svg" in content_type or b"<svg" in data[:1000].lower():
        root = ET.fromstring(data)
        if root.tag.rsplit("}", 1)[-1].lower() != "svg":
            raise ValueError("XML document root is not SVG")
        return {"format": "SVG", "width": root.get("width"), "height": root.get("height"), "viewBox": root.get("viewBox")}
    from PIL import Image
    with Image.open(io.BytesIO(data)) as image:
        details = {"format": image.format, "width": image.width, "height": image.height, "mode": image.mode}
        image.verify()
    return details


def download(url: str, products: list[str], destination: Path, timeout: int) -> dict:
    result = {"url": url, "products": products, "status": "pending"}
    try:
        request = Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; PublicPortfolioArchive/1.0)", "Accept": "image/avif,image/webp,image/svg+xml,image/*,*/*;q=0.8"})
        with urlopen(request, timeout=timeout) as response:
            content_type = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
            result.update({"http_status": response.status, "final_url": response.url, "content_type": content_type})
            data = response.read(30 * 1024 * 1024 + 1)
        if len(data) > 30 * 1024 * 1024:
            raise ValueError("asset exceeds 30 MiB per-file limit")
        if content_type in {"text/html", "application/xhtml+xml"} or data.lstrip()[:20].lower().startswith((b"<!doctype html", b"<html")):
            raise ValueError("server returned HTML rather than an image")
        if not content_type.startswith("image/") and content_type not in {"application/octet-stream", "binary/octet-stream", "application/xml", "text/xml", ""}:
            raise ValueError("unexpected non-image Content-Type: " + content_type)
        details = verify_image(data, content_type)
        relative = asset_relative_path(url, content_type, data)
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        result.update({"status": "downloaded", "local_path": str(Path("assets") / relative), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), **details})
    except HTTPError as exc:
        result.update({"status": "http_error", "http_status": exc.code, "error": str(exc)})
    except (URLError, TimeoutError, OSError, ValueError, ET.ParseError) as exc:
        result.update({"status": "failed", "error": f"{type(exc).__name__}: {exc}"})
    except Exception as exc:
        result.update({"status": "failed", "error": f"{type(exc).__name__}: {exc}"})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--timeout", type=int, default=15)
    parser.add_argument("--reuse-verified", action="store_true", help="Reuse previously verified local bytes whose hashes still match the manifest")
    args = parser.parse_args()
    root = args.root.resolve()
    source = root / "source"
    asset_dir = root / "assets"
    asset_dir.mkdir(parents=True, exist_ok=True)
    inventories = []
    url_products: dict[str, set[str]] = {}
    for product in PRODUCTS:
        metadata_path = source / f"{product}-rendered-metadata.json"
        metadata = json.loads(metadata_path.read_text())
        base_url = metadata.get("url") or metadata.get("final_url") or f"https://www.upaj.org/{product}"
        urls = explicit_image_urls(metadata, base_url)
        for url in urls:
            url_products.setdefault(url, set()).add(product)
        inventory = {"product": product, "url": base_url, "rendered_metadata": str(metadata_path.relative_to(root)), "image_url_count": len(urls), "image_urls": sorted(urls), "observed_image_elements": metadata.get("images", []), "observed_backgrounds": metadata.get("backgrounds", []), "observed_links": metadata.get("links", [])}
        for filename in (f"{product}-original.html", f"{product}-rendered.html", f"{product}-text.txt", f"{product}-rendered-text.txt"):
            path = source / filename
            if path.exists():
                inventory.setdefault("source_files", []).append({"path": str(path.relative_to(root)), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        inventories.append(inventory)
    results = []
    previous = {}
    manifest_path = source / "capture-manifest.json"
    if args.reuse_verified and manifest_path.exists():
        old_manifest = json.loads(manifest_path.read_text())
        previous = {item["url"]: item for item in old_manifest.get("assets", []) if item.get("status") == "downloaded"}
    to_download = {}
    for url, products in sorted(url_products.items()):
        cached = previous.get(url)
        path = root / cached["local_path"] if cached else None
        if cached and path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == cached.get("sha256"):
            result = dict(cached)
            result.update({"products": sorted(products), "reused_verified_local_bytes": True})
            results.append(result)
        else:
            to_download[url] = products
    with ThreadPoolExecutor(max_workers=min(max(args.workers, 1), 16)) as executor:
        futures = {executor.submit(download, url, sorted(products), asset_dir, args.timeout): url for url, products in sorted(to_download.items())}
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            if result["status"] != "downloaded":
                print(json.dumps({"url": result["url"], "status": result["status"], "error": result.get("error")}))
    results.sort(key=lambda item: item["url"])
    statuses = {}
    for result in results:
        statuses[result["status"]] = statuses.get(result["status"], 0) + 1
    hashes = {}
    for result in results:
        if result.get("sha256"):
            hashes.setdefault(result["sha256"], []).append(result["url"])
    manifest = {"project": "Upaj public product portfolio archive", "captured_at_utc": datetime.now(timezone.utc).isoformat(), "scope": "Public rendered Riskstac, Finstac and Growstac pages and their explicitly observed original image URLs only.", "products": inventories, "download_settings": {"workers": min(max(args.workers, 1), 16), "timeout_seconds": args.timeout, "max_asset_bytes": 30 * 1024 * 1024}, "summary": {"unique_urls": len(url_products), "download_status_counts": statuses, "unique_image_content_hashes": len(hashes), "total_downloaded_bytes": sum(item.get("bytes", 0) for item in results)}, "identical_content_url_groups": [urls for urls in hashes.values() if len(urls) > 1], "assets": results}
    output = source / "capture-manifest.json"
    output.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"manifest": str(output), **manifest["summary"]}, indent=2))


if __name__ == "__main__":
    main()
