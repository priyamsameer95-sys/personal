"""Build an offline gallery for the captured Upaj portfolio evidence."""
from pathlib import Path
from PIL import Image
import html,json

ROOT=Path(__file__).resolve().parents[1]
def e(s):return html.escape(str(s))
manifest=json.loads((ROOT/'source/capture-manifest.json').read_text())
def card(path,label):
 return '<figure><a href="'+e(path)+'"><img loading="lazy" src="'+e(path)+'" alt="'+e(label)+'"></a><figcaption>'+e(label)+'</figcaption></figure>'
products=[('riskstac','Riskstac','Agricultural lending and credit-risk support'),('finstac','Finstac','Agricultural insurance and distribution'),('growstac','Growstac','Precision agriculture and farmer-network support')]
sections=[]
for slug,name,description in products:
 shots=''.join(card(p.relative_to(ROOT),p.stem.replace('-',' '))for p in sorted((ROOT/'screenshots').glob(slug+'-*.jpg')))
 art=''.join(card(a['local_path'],Path(a['local_path']).name)for a in manifest['assets']if a.get('status')=='downloaded'and slug in Path(a['local_path']).name)
 sections.append('<section id="'+slug+'"><h2>'+name+'</h2><p>'+description+'</p><p><a href="https://www.upaj.org/'+slug+'">Original page</a> · <a href="source/'+slug+'-rendered-text.txt">Captured text</a> · <a href="source/'+slug+'-rendered.html">Rendered HTML</a></p><h3>Screen captures</h3><div class="gallery screens">'+shots+'</div><details><summary>Original product images</summary><div class="gallery">'+art+'</div></details></section>')
films=[]
for p in sorted((ROOT/'videos').glob('*.mp4')):
 preview=p.with_name(p.stem+'-preview.jpg');poster=p.with_name(p.stem+'-poster.jpg')
 if preview.exists():
  im=Image.open(preview);im.crop((0,0,640,360)).save(poster,quality=92)
 films.append('<figure><video controls preload="metadata" poster="'+e(poster.relative_to(ROOT))+'" src="'+e(p.relative_to(ROOT))+'"></video><figcaption><a href="'+e(p.relative_to(ROOT))+'">'+e(p.stem.replace('-',' '))+'</a></figcaption></figure>')
shared=''.join(card(a['local_path'],Path(a['local_path']).name)for a in manifest['assets']if a.get('status')=='downloaded'and not any(p[0]in Path(a['local_path']).name for p in products))
style='body{font:16px/1.65 system-ui,sans-serif;background:#f6f9f6;color:#16302a;margin:0}main{max-width:1200px;margin:auto;padding:44px 24px}h1{font-size:42px;margin:8px 0}h2{font-size:29px}h3{font-size:18px}a{color:#326b20}section,details{background:white;border:1px solid #dce6dc;border-radius:14px;padding:22px;margin:22px 0}.gallery{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}.screens{grid-template-columns:repeat(auto-fit,minmax(440px,1fr))}figure{margin:0;border:1px solid #e0e8df;border-radius:12px;overflow:hidden;background:white}img{display:block;width:100%;height:240px;object-fit:contain;background:#eef4ed}.screens img{height:330px}video{width:100%;display:block;background:#08281f}figcaption{padding:12px;font-size:13px;overflow-wrap:anywhere}small{color:#597069}summary{font-weight:650;cursor:pointer}pre{white-space:pre-wrap;font:14px/1.7 system-ui,sans-serif}.badge{font-size:13px;font-weight:700;letter-spacing:.12em;color:#496f23}.nav{display:flex;gap:24px;flex-wrap:wrap}@media(max-width:550px){.screens{grid-template-columns:1fr}main{padding:28px 16px}h1{font-size:32px}}'
out='<!DOCTYPE html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Upaj | Portfolio archive</title><style>'+style+'</style><main><div class="badge">PRIYAM SAMEER / PUBLIC PRODUCT RECORD</div><h1>Upaj product portfolio</h1><p>Riskstac · Finstac · Growstac</p><small>Captured 13 October 2026. Public content and screenshots, with source claims distinguished from tested operation.</small><section><p><a href="Upaj-Portfolio-Reference.pdf">Six-page portfolio reference</a> · <a href="workflow.json">Structured workflow notes</a> · <a href="README.txt">Archive notes</a> · <a href="source/capture-manifest.json">Asset inventory</a></p><div class="nav"><a href="#riskstac">Riskstac</a><a href="#finstac">Finstac</a><a href="#growstac">Growstac</a></div></section><h2>Short portfolio videos</h2><p>Three silent 20-second 1080p MP4 clips made from animated public-page captures. Operational product systems were not inspected.</p><div class="gallery">'+''.join(films)+'</div>'+''.join(sections)+'<details><summary>Shared brand and public website images</summary><div class="gallery">'+shared+'</div></details><section><h2>Workflow and evidence notes</h2><pre>'+e((ROOT/'README.txt').read_text())+'</pre></section></main></html>'
(ROOT/'index.html').write_text(out)
print('Built offline gallery for three products')
