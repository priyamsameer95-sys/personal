from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
from PIL import Image
import json
import html
import shutil

ROOT = Path(__file__).resolve().parents[2]
PACK = ROOT / 'upaj-portfolio'
OUT = ROOT / 'Upaj-Portfolio-Reference.pdf'
W, H = A4
M = 44
CW = W - 2*M
INK = HexColor('#152a24')
MUTED = HexColor('#5b6c65')
GREEN = HexColor('#15764d')
PALE = HexColor('#eaf4ed')
LINE = HexColor('#dce7df')
WARM = HexColor('#f6f9f6')

pdfmetrics.registerFont(TTFont('Inter', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('Inter-Bold', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFontFamily('Inter', normal='Inter', bold='Inter-Bold')
c = canvas.Canvas(str(OUT), pagesize=A4)
c.setTitle('Upaj | Portfolio Reference')
c.setAuthor('Prepared for Priyam Sameer')
c.setSubject('Dated public product and workflow evidence, 13 October 2026')

def text(s, x, y, size=10, color=INK, bold=False):
    c.setFillColor(color)
    c.setFont('Inter-Bold' if bold else 'Inter', size)
    c.drawString(x, y, s)

def para(s, x, top, width=CW, size=10, leading=15, color=INK, bold=False):
    style = ParagraphStyle('p', fontName='Inter-Bold' if bold else 'Inter', fontSize=size,
                           leading=leading, textColor=color, spaceAfter=0)
    p = Paragraph(s, style)
    _, h = p.wrap(width, 1000)
    p.drawOn(c, x, top-h)
    return top-h

def line(y):
    c.setStrokeColor(LINE)
    c.setLineWidth(.7)
    c.line(M,y,W-M,y)

def label(s,x,y,color=GREEN):
    text(s.upper(),x,y,8.2,color,True)

def header(n, topic):
    c.setFillColor(white)
    c.rect(0,0,W,H,fill=1,stroke=0)
    c.setFillColor(GREEN)
    c.rect(M,H-48,26,3,fill=1,stroke=0)
    label('UPAJ  /  PORTFOLIO REFERENCE',M,H-66)
    text(topic,M,H-99,25,INK,True)
    line(50)
    text('PUBLIC PRODUCT RECORD  |  13 OCT 2026',M,31,7.1,MUTED)
    c.setFont('Inter-Bold',8)
    c.drawRightString(W-M,31,f'{n:02d} / 06')

def shot(name,x,top,width,height=None,crop=None):
    path=PACK/'screenshots'/name
    im=Image.open(path).convert('RGB')
    if crop: im=im.crop(crop)
    iw,ih=im.size
    if height is None: height=width*ih/iw
    c.drawImage(ImageReader(im),x,top-height,width=width,height=height)
    c.setStrokeColor(LINE)
    c.roundRect(x,top-height,width,height,5,stroke=1,fill=0)
    return top-height

def card(x,top,width,height,fill=PALE):
    c.setFillColor(fill)
    c.roundRect(x,top-height,width,height,9,fill=1,stroke=0)

def hero_shot(p,top,width=CW):
    im=Image.open(PACK/'screenshots'/p['hero'])
    iw,ih=im.size
    crop=p.get('hero_crop') or (0,0,iw,min(ih,round(iw*260/CW)))
    return shot(p['hero'],M+(CW-width)/2,top,width,crop=crop)

def cells(rows,widths,top,font_size=8.4):
    style=ParagraphStyle('cell',fontName='Inter',fontSize=font_size,leading=font_size*1.45,textColor=INK)
    style_b=ParagraphStyle('cellb',parent=style,fontName='Inter-Bold')
    data=[[Paragraph(s,style_b if row_id==0 else style) for s in row] for row_id,row in enumerate(rows)]
    t=Table(data,colWidths=widths)
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),PALE),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),
        ('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),
        ('LINEBELOW',(0,0),(-1,-1),.5,LINE)
    ]))
    _,h=t.wrap(CW,1000)
    t.drawOn(c,M,top-h)
    return top-h

def main():
    data=json.loads((PACK/'source'/'portfolio-reference-content.json').read_text())
    build(data)
    c.save()
    shutil.copy2(OUT,PACK/OUT.name)
    print(OUT)

def build(data):
    products=data['products']
    header(1,'Agriculture, through three lenses')
    para('RiskStac, FinStac and GrowStac. A visual record of Upaj\'s public product propositions, preserved for Priyam Sameer\'s portfolio.',
         M,H-121,CW,size=11.5,leading=17,color=MUTED)
    bottom=hero_shot(products[0],644)
    para('CAPTURED PUBLIC WEBSITE  /  RiskStac landing page. Original site screenshots and image assets are retained in the archive.',
         M,bottom-10,CW,size=7.5,leading=11,color=MUTED)
    y=bottom-52
    cols=(CW-24)/3
    for i,p in enumerate(products):
        x=M+i*(cols+12)
        card(x,y,cols,107)
        label(p['name'],x+13,y-21)
        para(p['short'],x+13,y-35,cols-26,size=9.2,leading=13)
        para(p['audience'],x+13,y-73,cols-26,size=7.8,leading=11,color=MUTED)
    y-=134
    label('PORTFOLIO CONTEXT',M,y)
    para('Prepared for <b>Priyam Sameer</b>. The archive records the public-facing Upaj / Absolute product material selected by Priyam. Product-specific responsibilities and measured outcomes should be added from his project records.',
         M,y-14,CW,size=9.1,leading=13)
    para('Capture date: 13 October 2026. These pages show solution marketing, explanatory assets and contact entry points; authenticated operations are outside this record.',
         M,y-68,CW,size=8.2,leading=12,color=MUTED)
    c.showPage()

    for n,p in enumerate(products,2):
        header(n,p['name'])
        para(p['positioning'],M,H-121,CW,size=11.2,leading=16.5,color=MUTED)
        bottom=hero_shot(p,651,CW-40)
        para('PUBLIC LANDING PAGE  /  '+p['url'],M,bottom-10,CW,size=7.5,leading=11,color=MUTED)
        y=bottom-47
        label('WHAT THE PAGE PRESENTS',M,y)
        y=para(p['summary'],M,y-15,CW,size=9.3,leading=14)-18
        for title,body in p['offerings']:
            text(title,M,y,9.6,GREEN,True)
            y=para(html.escape(body),M,y-9,CW,size=8.7,leading=12.8)-17
        line(y+5)
        label('PRODUCT LOGIC  /  PAGE-DESCRIBED',M,y-13)
        y=para(p['workflow'],M,y-28,CW,size=8.8,leading=13)-14
        para(p['boundary'],M,y,CW,size=8.1,leading=12,color=MUTED)
        c.showPage()

    header(5,'The public journey')
    para('The three pages share an enterprise solution-discovery pattern. This map records public navigation and explanatory content, rather than a completed customer transaction.',
         M,H-121,CW,size=10.5,leading=16,color=MUTED)
    top=667
    rows=[
        ['Stage','What is visible','What it establishes'],
        ['01  Discover','Product-specific hero and value proposition; site navigation across solutions.','The target problem and intended audience.'],
        ['02  Understand','"Why" / "How it works" content and offering panels.','The solution logic advertised by the site.'],
        ['03  Evaluate','Impact-story cards and a shared testimonial section.','Public supporting material; not independent outcome validation.'],
        ['04  Make contact','GrowStac inquiry form: interest, name, email, country, mobile, organisation, designation and help message.','Blank personal fields; India / +91 defaults. No personal information entered or submitted. Other pages: demo CTA viewed.'],
        ['05  Return as a business','"Already a registered business with us? LOGIN HERE".','A separate sign-in route; authenticated workflows were not captured.']
    ]
    y=cells(rows,[104,202,CW-306],top,8.6)-27
    label('CONCEPTUAL PRODUCT FLOWS',M,y)
    y-=18
    for p in products:
        card(M,y,CW,66,WARM)
        label(p['name'],M+14,y-19)
        para(p['flow_short'],M+114,y-11,CW-129,size=9.1,leading=14)
        y-=78
    para('Conceptual flows summarize the published propositions. No API sequence, scoring model, underwriting decision, agronomy recommendation or backend integration is inferred from them.',
         M,y-2,CW,size=8.1,leading=12,color=MUTED)
    c.showPage()

    header(6,'Evidence that travels with the work')
    para('This reference keeps visible interfaces, page-stated capabilities and portfolio attribution distinct so the material can support a clear, defensible case study.',
         M,H-121,CW,size=10.5,leading=16,color=MUTED)
    label('SOURCE RECORD',M,669)
    para('<b>Primary pages:</b><br/>https://www.upaj.org/riskstac<br/>https://www.upaj.org/finstac<br/>https://www.upaj.org/growstac<br/><b>Observed title:</b> "UPAJ - Absolute". <b>Capture date:</b> 13 October 2026.<br/><b>Capture scope:</b> public pages, offering tabs, GrowStac\'s blank inquiry form and image assets. No personal information was entered; no forms, subscriptions or demo requests were submitted.',
         M,652,CW,size=8.5,leading=13)
    for i,p in enumerate(products):
        c.linkURL(p['url'],(M,626-i*13,M+226,639-i*13),relative=0,thickness=0)
    rows=[['Evidence','Reusable material','Qualification']]+data['evidence_rows']
    y=cells(rows,[111,195,CW-306],543,8.0)-23
    label('PRIYAM\'S CONTRIBUTION FIELDS',M,y)
    y=para('Complete these from delivery records before making personal claims: <b>role and dates</b>; <b>scope and decision rights</b>; <b>team and collaborators</b>; <b>problem and alternatives</b>; <b>key decisions and trade-offs</b>; <b>shipped components</b>; <b>outcomes with baseline, period and attribution</b>.',
           M,y-14,CW,size=8.6,leading=13)-17
    para('The archive preserves original artwork as evidence of the product\'s public presentation. It does not establish individual authorship of the website, images, models or operational systems.',
         M,y,CW,size=8.0,leading=12,color=MUTED)
    c.showPage()

if __name__=='__main__':
    main()
