"""Make silent 1080p Upaj portfolio clips from archived public captures.

No live screen recording, OTP verification or application submission is implied.
Requires Python 3, Pillow, ffmpeg and the archived screenshots/assets.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
import concurrent.futures, json, math, subprocess

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'videos'
OUT.mkdir(exist_ok=True)
W,H,FPS=1920,1080,24
FONT=Path('/usr/share/fonts/truetype/dejavu')
def font(n,bold=False):return ImageFont.truetype(str(FONT/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')),n)
F44,F22,F54,F27,F19=font(44,True),font(22),font(54,True),font(27),font(19)

S=ROOT/'screenshots'
A=ROOT/'assets/images/how-it-works'
CLIPS=json.loads('[{"file": "Upaj-01-Riskstac.mp4", "title": "AGRI-LENDING RISK", "brand": "UPAJ / RISKSTAC", "url": "upaj.org/riskstac", "kind": "Animated public-page captures; capabilities described by the site", "scenes": [{"file": "riskstac-hero.jpg", "crop": [0, 0, 1363, 735], "seconds": 6, "title": "Credit risk\\nin agriculture", "detail": "Public positioning for the agri-lending industry.", "label": "Public product page"}, {"file": "riskstac-data-inputs.jpg", "crop": [80, 118, 1260, 925], "seconds": 7, "title": "Farm-level\\ndata inputs", "detail": "Satellite, IoT, weather and soil-health data shown in the published workflow.", "label": "Website-described data inputs"}, {"file": "riskstac-repayment-risk.jpg", "crop": [70, 302, 1320, 936], "seconds": 7, "title": "Portfolio risk\\nsupport", "detail": "The page presents repayment-risk mitigation and farm-monitoring offerings.", "label": "Inspected public offering tab"}]}, {"file": "Upaj-02-Finstac.mp4", "title": "AGRICULTURAL INSURANCE", "brand": "UPAJ / FINSTAC", "url": "upaj.org/finstac", "kind": "Animated public-page captures; capabilities described by the site", "scenes": [{"file": "finstac-hero.jpg", "crop": [0, 0, 1363, 735], "seconds": 6, "title": "Climate and\\nfinancial resilience", "detail": "The public agricultural-insurance proposition.", "label": "Public product page"}, {"file": "finstac-diy-platform.jpg", "crop": [70, 302, 1320, 936], "seconds": 7, "title": "DIY crop\\ninsurance", "detail": "DigiFasal is presented through the Upaj app and APIs.", "label": "Inspected public offering tab"}, {"file": "finstac-insurance-products.jpg", "crop": [70, 302, 1320, 936], "seconds": 7, "title": "Custom insurance\\nproducts", "detail": "The page describes tailored insurance products backed by agronomy, underwriting and technology.", "label": "Website-described capability"}]}, {"file": "Upaj-03-Growstac.mp4", "title": "PRECISION AGRICULTURE", "brand": "UPAJ / GROWSTAC", "url": "upaj.org/growstac", "kind": "Animated public-page captures; capabilities described by the site", "scenes": [{"file": "growstac-hero.jpg", "crop": [0, 0, 1363, 755], "seconds": 6, "title": "Precision\\nagriculture", "detail": "Farm-level data and insights for enterprises and farmers.", "label": "Public product page"}, {"file": "growstac-advisory.jpg", "crop": [70, 302, 1320, 936], "seconds": 7, "title": "Data-backed\\nadvisory", "detail": "The page presents advisory delivered as a checklist in the Upaj app.", "label": "Inspected public offering tab"}, {"file": "growstac-technology.jpg", "crop": [70, 302, 1320, 936], "seconds": 7, "title": "Agricultural\\ntechnology", "detail": "IoT sensor suites, satellite information and soil-health data are described as inputs.", "label": "Website-described capability"}]}]')
for clip in CLIPS:
    for scene in clip["scenes"]:scene["file"]=S/scene["file"]

def wrapped(draw,text,face,width):
    lines=[]
    for paragraph in text.split('\n'):
        line=''
        for word in paragraph.split():
            new=(line+' '+word).strip()
            if draw.textlength(new,font=face)>width and line:lines.append(line);line=word
            else:line=new
        lines.append(line)
    return lines

def draw_scene(clip,scene,index,p):
    frame=Image.new('RGB',(W,H),'#08281f');d=ImageDraw.Draw(frame)
    d.text((54,34),clip['brand'],font=F44,fill='#ffffff')
    d.text((56,92),clip['title'],font=F22,fill='#b4d56d')
    d.text((1535,50),'PORTFOLIO / 13 OCT 2026',font=F19,fill='#afc1d5')
    box=(54,146,1360,950);bw,bh=1306,804
    d.rounded_rectangle((46,139,1368,958),radius=17,fill='#25493b')
    d.rounded_rectangle(box,radius=12,fill='#f0f5fb')
    im=scene['_image'];base_scale=min(bw/im.width,bh/im.height)
    ease=(1-math.cos(math.pi*p))/2
    scale=base_scale*(1+.027*ease)
    scaled=im.resize((round(im.width*scale),round(im.height*scale)),Image.Resampling.LANCZOS)
    visual=Image.new('RGB',(bw,bh),'#f0f5fb')
    visual.paste(scaled,((bw-scaled.width)//2,(bh-scaled.height)//2))
    mask=Image.new('L',(bw,bh),0);ImageDraw.Draw(mask).rounded_rectangle((0,0,bw,bh),radius=12,fill=255)
    frame.paste(visual,(54,146),mask)
    d=ImageDraw.Draw(frame)
    d.rounded_rectangle((1420,230,1508,281),radius=13,fill='#486b22')
    d.text((1443,238),f'{index+1:02d}',font=font(27,True),fill='white')
    y=318
    for line in wrapped(d,scene['title'],F54,430):d.text((1420,y),line,font=F54,fill='white');y+=68
    y+=28
    for line in wrapped(d,scene['detail'],F27,420):d.text((1420,y),line,font=F27,fill='#bbd0e6');y+=41
    d.line((1420,806,1835,806),fill='#33516e',width=2)
    y=828
    for line in wrapped(d,scene['label'],F22,425):d.text((1420,y),line,font=F22,fill='#b4d56d');y+=31
    footer='Animated public-page captures  |  Site-described capabilities  |  13 Oct 2026'
    d.text((54,990),footer,font=F19,fill='#a6bed8')
    d.text((1520,990),clip['url'],font=F19,fill='#c5d9ee')
    return frame

def render(clip):
    scenes=clip['scenes'];total=sum(x['seconds'] for x in scenes);dest=OUT/clip['file']
    for s in scenes:
        im=Image.open(s['file']).convert('RGB')
        if s.get('crop'):im=im.crop(s['crop'])
        s['_image']=im
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-threads','3','-movflags','+faststart','-metadata','title=Upaj '+clip['title'].title(),'-metadata','comment='+clip['kind']+'; public source captured 13 October 2026; not a live screen recording.',str(dest)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    previous=None;n=0;thumbs=[]
    try:
        for i,s in enumerate(scenes):
            count=round(s['seconds']*FPS)
            for j in range(count):
                frame=draw_scene(clip,s,i,j/max(1,count-1))
                if previous is not None and j<round(.3*FPS):frame=Image.blend(previous,frame,j/round(.3*FPS))
                d=ImageDraw.Draw(frame);d.rounded_rectangle((54,1040,1866,1046),radius=3,fill='#294764');d.rounded_rectangle((54,1040,54+round(1812*(n+1)/(total*FPS)),1046),radius=3,fill='#b4d56d')
                if j==count//2:thumbs.append(frame.resize((640,360),Image.Resampling.LANCZOS))
                proc.stdin.write(frame.tobytes());n+=1
            previous=frame
        proc.stdin.close();rc=proc.wait()
        if rc:raise RuntimeError(f'ffmpeg exited {rc}')
    except Exception:
        proc.kill();raise
    sheet=Image.new('RGB',(640*len(thumbs),360),'white')
    for i,t in enumerate(thumbs):sheet.paste(t,(i*640,0))
    sheet.save(OUT/(dest.stem+'-preview.jpg'),quality=92)
    print(json.dumps({'file':dest.name,'seconds':total,'frames':n,'bytes':dest.stat().st_size}),flush=True)
    return {'file':dest.name,'duration_seconds':total,'width':W,'height':H,'fps':FPS,'audio':False,'source_type':clip['kind'],'scenes':[{'seconds':s['seconds'],'title':s['title'].replace('\n',' '),'source_file':str(s['file'].relative_to(ROOT)),'label':s['label']}for s in scenes]}

if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:records=list(pool.map(render,CLIPS))
    (OUT/'video-manifest.json').write_text(json.dumps({'project':'Upaj','capture_date':'2026-10-13','description':'Silent animated public-page captures and original website illustrations. Not live screen recordings; no authenticated application workflow captured.','videos':records},indent=2))
    (OUT/'README.txt').write_text('Three 20-second, silent, 1080p MP4 portfolio clips.\n01 Riskstac; 02 Finstac; 03 Growstac.\nCreated from saved public screenshots and original site illustrations captured on 13 October 2026.\nThese animate public marketing pages; they do not show authenticated product operation, lender decisions or insurance transactions.\nAll capabilities are described by the captured public pages.\n')
