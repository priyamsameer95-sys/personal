UPAJ | PORTFOLIO SOURCE ARCHIVE
Riskstac, Finstac and Growstac | Captured 13 October 2026
Prepared for Priyam Sameer's portfolio reference.

SCOPE
Three unique public product pages were captured:
https://www.upaj.org/riskstac
https://www.upaj.org/finstac
https://www.upaj.org/growstac
The duplicated/malformed Finstac/Growstac link in the request was resolved into these three pages.

CONTENTS
Upaj-Portfolio-Reference.pdf: six-page product and workflow reference.
screenshots/: product heroes, data inputs, inspected offering tabs and the empty Growstac demo inquiry form.
assets/: 50 verified original website image assets, including six hero backgrounds, twelve workflow illustrations and eleven offering illustrations, plus shared branding and public marketing art.
source/: original Angular page shells, rendered HTML/text, separate offering-tab states, exact download inventory and evidence notes.
videos/: three silent 20-second 1080p MP4 clips, one each for Riskstac, Finstac and Growstac.
scripts/: reusable asset downloader, reference builder, video renderer and offline index builder.
workflow.json: structured public interaction and capability notes, with evidence labels.
index.html: offline gallery for browsing the preserved material after extraction.

PRODUCT CONTEXT
Riskstac presents credit-risk support for agricultural lending: farm credit reports, repayment-risk mitigation and farm monitoring. Its published data inputs include satellite information, IoT sensors, weather/climate data and soil health.
Finstac presents agricultural insurance: a DigiFasal DIY offering, physical-and-digital distribution, tailored insurance products and climate resilience. The page describes app/API access and a POS/paravet network; their operational implementation was not independently tested.
Growstac presents precision agriculture: advisory, technology, research projects and personalised farmer-network solutions. Its public copy describes AI/ML advisory checklists, IoT/satellite/soil inputs, agronomic research and support.
These are three parallel product propositions. This archive does not establish that they form a single connected operational sequence.

INSPECTED PUBLIC JOURNEY
Open a product page, inspect its proposition and data/workflow section, switch public offering tabs, and view the demo call to action.
On Growstac, Schedule A demo revealed an empty inquiry form. Inspected fields were product interest, name, email, country, phone code/mobile, organisation, designation and help message. The country default was India with +91 displayed.
The product-interest menu listed Rural Loans, Rural Insurance, Soil testing, Upaj App/Advisory Services and Anything Else.
No personal information was entered. No inquiry was submitted, newsletter subscribed to or account accessed. An illustrative Rural Insurance interest choice was selected while inspecting the menu; this is not Priyam's stated service preference.

EVIDENCE BOUNDARIES
Observed: publicly rendered pages, offering-tab switches, associated text/art, public demo affordances and the empty Growstac inquiry form.
Page-described: farm scoring/reporting, portfolio monitoring, API delivery, insurance capabilities, AI/ML advisory and customised research/support.
Not inspected: authenticated lender, insurer, agent, farmer or admin screens; underwriting results; operational APIs; policy purchase; loan decisions; backend architecture; model quality; production telemetry.
Source marketing metrics, impact headlines and testimonials are preserved as dated website material rather than verified personal achievements.
Priyam's exact role, dates, ownership, shipped decisions, collaborators and measured outcomes should be attached before converting this source archive into a final personal case study.
The videos animate archived public screenshots. They do not record real underwriting, insurance issuance or authenticated product operation.

REUSE
Extract the ZIP, then open index.html. Click an image for its original file or play the MP4 clips in the video gallery.
The saved HTML is evidence of captured content, not a guaranteed functional offline application.
The site uses client-side rendering. Original page HTML alone contains an application shell; the rendered exports and tab-state files retain the visible product details.
The asset scraper reads those concrete rendered metadata exports and downloads only observed public image URLs. Use --reuse-verified to refresh the inventory without downloading unchanged images again.
