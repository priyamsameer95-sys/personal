URBANKHET — FOUNDER PORTFOLIO ARCHIVE
Prepared for Priyam Sameer on 13 October 2026

OPEN THE PORTFOLIO ENTRY
Extract the entire ZIP to one folder, then open index.html in a web browser.
Keep its folders together: image and document links use relative paths.
The page uses local files and system fonts. Internet access is required only
when you choose an external source link. No videos are included.

MAIN FILES
index.html — responsive offline portfolio entry with a campaign gallery,
dated evidence panels, source links and downloadable files.
UrbanKhet-Portfolio-Case-Study.pdf — detailed, designed case study and evidence.
UrbanKhet-Portfolio-Case-Study.docx — editable document counterpart.
portfolio-case-copy.txt — longer first-person text for a portfolio page.
portfolio-short-summary.txt — compact first-person portfolio description.
assets/UrbanKhet-Infographic.svg — editable vector business-model infographic.
assets/UrbanKhet-Infographic.png — raster version of the same infographic.
assets/UrbanKhet-Original-Interpretation.png — original editorial illustration;
this is conceptual artwork, not a photograph or an operational record.
assets/UrbanKhet-Original-Logo.png — original company logo preserved from
the IIMA Ventures official portfolio listing.
assets/studio/ — 10 original Studio Sorted campaign images/poster stills.
source/ — curated reference index and campaign-asset metadata/provenance.
scripts/ — reproducible generators and the project-source asset scraper.

HOW TO READ THE CASE
The sources describe different stages of a historical venture: early urban
farming, a June 2020 farm-to-household supply operation and later
founder-reported B2B expansion. The exact pivot date
is not documented. The 2018–2021 operating period and winding-down account
come from founder career records, not a verified legal-status lookup.

See the dated June 2020 operational snapshot in the infographic. These are
newsletter-reported figures based on nodal-institution inputs, not an audit.

Later founder records: 3,400 B2C customers, 3,000 farmers reached and wastage
from 35% to 10%. Measurement periods and methods are unavailable. Do not
equate farmer reach with active supplier relationships or blend the two
snapshots into one dated outcome.

Recognition is named precisely: GUSEC Rise Award (event 26 February 2021),
GUSEC TIDE 2.0 portfolio and IIMA Ventures' official investment portfolio.
The IIMA listing does not state an investment amount, date or round.
No current ordering service, legal status, pricing, profitability or software
feature is asserted. Instagram and F6S did not yield substantive content.

CREATIVE CREDIT
Studio Sorted produced the historical campaign images. Creative direction:
Abhishek Durani. Graphic design and illustration: Ritam Mukherjee, Ishita
Poddar and Tanmay Acharya. Design management: Netra Ajjampur.
Their source page does not state a reuse licence. Preserve attribution.
The separately labelled infographic and editorial illustration were created
for this portfolio; they are not the original commissioned campaign.

SOURCE URLS — CORRECTED FROM THE CONCATENATED LINK
https://www.studiosorted.com/work/urbankhet
https://www.linkedin.com/company/khet-inc/
https://www.instagram.com/urbankhet/
https://www.f6s.com/member/priyamsameer1

REBUILD THE ENTRY
From the extracted folder, run:
python3 scripts/build_portfolio_entry.py
The generator reads JSON metadata and writes index.html and this README.
Python's standard library is sufficient; no network access is used.
