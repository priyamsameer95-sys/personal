#!/usr/bin/env python3
"""Archive observed UrbanKhet case-page images, excluding video downloads.

Source: https://www.studiosorted.com/work/urbankhet
All image links are observed in the supplied case page. This does not establish
copyright ownership or grant a reuse licence. The public page credits Studio
Sorted's creative team. Raw source and manifests preserve that attribution.
"""
import concurrent.futures
import hashlib
import io
import json
import re
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "source" / "studio"
ASSETS = ROOT / "assets" / "studio"
URL = "https://www.studiosorted.com/work/urbankhet"

class CaseParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images, self.links, self.videos, self.text = [], [], [], []
        self.ignore = 0
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in ("script", "style"): self.ignore += 1
        if tag == "img": self.images.append(a)
        if tag == "a" and a.get("href"): self.links.append(a["href"])
        if tag == "video":
            poster = a.get("poster")
            if not poster:
                m = re.search(r'url\([\"\x27]?(.*?)[\"\x27]?\)', a.get("style", ""))
                poster = m.group(1) if m else None
            self.videos.append({"id":a.get("id"), "poster":poster, "sources":[]})
        if tag == "source" and self.videos and a.get("src"):
            self.videos[-1]["sources"].append(a["src"])
    def handle_endtag(self, tag):
        if tag in ("script", "style"): self.ignore = max(0,self.ignore-1)
        if tag in ("p", "h1", "h2", "h3", "div", "section"): self.text.append("\n")
    def handle_data(self, data):
        if not self.ignore and data.strip(): self.text.append(data.strip() + " ")

def fetch(url):
    # Encode only unsafe characters in URLs; preserve observed host/path/query.
    url = urllib.parse.quote(url, safe=":/?&=%+#")
    r = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0 (portfolio research archive)"}),timeout=45)
    b = r.read()
    return b, {"requested_url":url,"final_url":r.geturl(),"status":r.status,"content_type":r.headers.get("Content-Type")}

def download(item):
    try:
        b, info = fetch(item["url"])
        img = Image.open(io.BytesIO(b)); img.verify()
        img = Image.open(io.BytesIO(b))
        ext = "." + ("jpg" if img.format == "JPEG" else img.format.lower())
        name = item["slug"] + ext
        (ASSETS / name).write_bytes(b)
        return {**item,**info,"file":"assets/studio/"+name,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"width":img.width,"height":img.height,"format":img.format,"status":"verified"}
    except Exception as e:
        return {**item,"status":"failed","error":str(e)}

def main():
    SRC.mkdir(parents=True,exist_ok=True); ASSETS.mkdir(parents=True,exist_ok=True)
    b, metadata = fetch(URL)
    (SRC/"original.html").write_bytes(b)
    p = CaseParser(); p.feed(b.decode("utf-8"))
    text = re.sub(r"\n\s*\n+", "\n", "".join(p.text)).strip()
    (SRC/"text.txt").write_text(text+"\n")
    selected = []
    titles = [
        ("urbankhet-superhero-market", "Hero illustration: UrbanKhet figure over a chaotic produce market"),
        ("urbankhet-farmer-market", "Campaign illustration: farmer figure over a confused market"),
        ("market-detail-09", "Market illustration detail 1; original page caption: illustration zoom in"),
        ("market-detail-06", "Market illustration detail 2; original page caption: illustration zoom in"),
        ("market-detail-08", "Market illustration detail 3; original page caption: illustration zoom in"),
        ("market-detail-07", "Market illustration detail 4; original page caption: illustration zoom in"),
        ("customer-fresh-vegetables", "Illustration of a customer receiving fresh vegetables"),
        ("delivery-straight-outta-khet", "Doorstep produce-delivery illustration"),
    ]
    relevant = [im for im in p.images if "Artboard" in im.get("src", "")]
    for im, (slug, caption) in zip(relevant,titles):
        selected.append({"url":im["src"],"slug":slug,"caption":caption,"original_alt":im.get("alt", ""),"kind":"original case-page illustration","srcset":im.get("srcset"),"creator":"Studio Sorted; credited creative team","rights":"Copyright/reuse licence not stated on case page; retain agency attribution. User identifies UrbanKhet as their company."})
    for i,v in enumerate(p.videos,1):
        if v.get("poster"):
            selected.append({"url":v["poster"],"slug":f"campaign-poster-{i:02}","caption":"Published poster still for " + ("How UrbanKhet works" if i==1 else "COVID-19 farmer-to-consumer animated campaign"),"original_alt":"","kind":"original published video poster still; video not downloaded","creator":"Studio Sorted; credited creative team","rights":"Copyright/reuse licence not stated on case page; retain agency attribution. User identifies UrbanKhet as their company."})
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(download, selected))
    manifest = {"source":URL,"retrieved_at":datetime.now(timezone.utc).isoformat(),"source_response":metadata,"html_sha256":hashlib.sha256(b).hexdigest(),"assets":results,"excluded_videos":p.videos,"all_observed_links":list(dict.fromkeys(p.links)),"all_observed_images":p.images,"policy":"No video downloads. Original high-resolution src image URLs are archived; responsive derivatives and site logos/controls are omitted."}
    (SRC/"asset-manifest.json").write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+"\n")
    print(json.dumps({"verified":sum(r["status"]=="verified" for r in results),"failed":sum(r["status"]=="failed" for r in results),"bytes":sum(r.get("bytes",0) for r in results),"manifest":str(SRC/"asset-manifest.json")},indent=2))

if __name__ == "__main__": main()
