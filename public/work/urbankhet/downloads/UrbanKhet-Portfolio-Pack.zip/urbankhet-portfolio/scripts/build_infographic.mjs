/**
 * UrbanKhet founder portfolio infographic.
 * Reconstructed factual workflow from the Startup Gujarat June 2020 newsletter,
 * p08; later scale and B2B buyers are separately labelled founder records.
 * Creates an original vector diagram, not a replica of partner artwork.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const sharp = require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'sharp'));
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const OUT = path.join(ROOT, 'assets');
const W = 1400, H = 2200;
const C = {
  cream: '#F4F0E5', forest: '#183E32', sage: '#DCE5D3', muted: '#5E7065',
  rule: '#BCC9BA', ochre: '#B98B34', paleOchre: '#EDE1C8', white: '#FFFDF5',
};
const esc = (v) => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const text = (x,y,s,size=26,opts={}) => `<text x="${x}" y="${y}" font-size="${size}" fill="${opts.fill||C.forest}" font-weight="${opts.weight||400}" text-anchor="${opts.anchor||'start'}"${opts.spacing ? ` letter-spacing="${opts.spacing}"` : ''}>${esc(s)}</text>`;
const lines = (x,y,arr,size=26,gap=36,opts={}) => arr.map((s,i)=>text(x,y+i*gap,s,size,opts)).join('');
const line = (x1,y1,x2,y2,color=C.rule,sw=2) => `<path d="M${x1} ${y1}H${x2}" stroke="${color}" stroke-width="${sw}"/>`;
const box = (x,y,w,h,fill,rx=0) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" rx="${rx}"/>`;
const icon = (name,x,y) => {
  const head=`<g transform="translate(${x} ${y})" fill="none" stroke="${C.forest}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">`;
  const tail='</g>';
  const icons={
    sprout:'<path d="M0 30V-1M0 6C-29 7-32-17-30-20C-10-21 1-10 0 6ZM0-1C2-20 23-25 29-22C31-3 12 3 0-1Z"/><path d="M-37 33H37"/>',
    crate:'<rect x="-37" y="-10" width="74" height="46" rx="3"/><path d="M-23-10V35M0-10V35M23-10V35M-37 4H37M-37 20H37"/><path d="M-20-13C-30-26-9-30-13-13M0-13C-8-38 12-32 7-13M19-13C10-26 35-33 29-13"/>',
    pin:'<path d="M0 34S-27 8-27-9a27 27 0 1 1 54 0C27 8 0 34 0 34Z"/><circle cx="0" cy="-9" r="9"/><path d="M-40 35H-15M15 35H40"/>',
    delivery:'<circle cx="-12" cy="-27" r="10"/><path d="M-26-4c0-14 28-14 28 0v16M-26-4v17M-23 11v26M-4 11v26M-26 9l17 8M2 5l9 10"/><rect x="6" y="-7" width="31" height="27" rx="2"/><path d="M21-7V3"/>',
    home:'<path d="M-37-2 0-32 37-2M-27-9V33H27V-9M-8 33V7H8V33M-19-18V-33H-10V-25"/>',
    shop:'<path d="M-33-12V32H33V-12M-39-12l8-21H31l8 21M-39-12c0 12 16 12 16 0 0 12 15 12 15 0 0 12 16 12 16 0 0 12 15 12 15 0 0 12 16 12 16 0M-19 32V9H-2V32M9 8H25V21H9Z"/>',
  };
  return head+icons[name]+tail;
};
const svgParts=[];
svgParts.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-labelledby="title desc">
<title id="title">UrbanKhet: from urban farming to farm-to-city fulfilment</title>
<desc id="desc">A historical founder portfolio infographic. Urban farming origins are recorded in the 2018 company profile. The four-step supply chain and the public snapshot are from Startup Gujarat's June 2020 newsletter. Later scale and B2B buyers are founder-reported and have no specified measurement window.</desc>
<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="${C.ochre}"/></marker></defs>
<style>text{font-family:'DejaVu Sans',sans-serif}</style>`);
svgParts.push(box(0,0,W,H,C.cream));
svgParts.push(text(80,65,'FOUNDER CASE STUDY  /  AHMEDABAD',20,{weight:700,spacing:2.3}));
svgParts.push(text(80,169,'UrbanKhet',88,{weight:700}));
svgParts.push(icon('sprout',1240,125));
svgParts.push(lines(80,243,['From urban growing','to farm-to-city fulfilment.'],44,55,{weight:400}));
svgParts.push(text(80,351,'Founded by Priyam Sameer',25,{weight:700}));
svgParts.push(lines(80,405,[
  'UrbanKhet connected growers with city produce buyers,',
  'organising farm preparation, handoffs and doorstep delivery.',
],27,39));

// A dated origin and an operational snapshot, rather than an invented pivot date.
svgParts.push(line(80,490,1320,490));
svgParts.push(text(80,533,'2018  /  URBAN FARMING ORIGINS',19,{weight:700,spacing:1.1}));
svgParts.push(lines(80,580,['Grow food in underused city spaces.','The early profile described urban farms.'],24,35));
svgParts.push(text(755,533,'JUNE 2020  /  DOCUMENTED SERVICE',19,{weight:700,spacing:1.1}));
svgParts.push(lines(755,580,['Connect existing farms with city demand.','Farm-to-home fulfilment in Ahmedabad.'],24,35));
svgParts.push(`<path d="M680 532V626" stroke="${C.rule}" stroke-width="2"/>`);
svgParts.push(text(80,657,'Origin: company profile. Service: Startup Gujarat newsletter, June 2020.',18,{fill:C.muted}));

svgParts.push(text(80,739,'How the produce moved',37,{weight:700}));
svgParts.push(text(80,781,'UrbanKhet coordinated the route · documented June 2020',23,{fill:C.muted}));
const steps=[
  {x:218,n:'01',i:'crate',label:['Farm preparation'],body:['Farmers sort, weigh','and pack produce','at the farm.']},
  {x:540,n:'02',i:'pin',label:['City handoff'],body:['Produce arrives at','predefined city','nodal points.']},
  {x:862,n:'03',i:'delivery',label:['Assigned delivery'],body:['Delivery personnel','collect the produce','for the final leg.']},
  {x:1184,n:'04',i:'home',label:['Households'],body:['Consumers receive','fresh produce','at their doorstep.']},
];
for (let k=0;k<steps.length;k++) {
  const s=steps[k];
  svgParts.push(`<circle cx="${s.x}" cy="872" r="61" fill="${C.sage}"/>`);
  svgParts.push(icon(s.i,s.x,866));
  svgParts.push(text(s.x,966,s.label[0],26,{weight:700,anchor:'middle'}));
  svgParts.push(lines(s.x,1012,s.body,23,33,{anchor:'middle'}));
  if(k<steps.length-1) svgParts.push(`<path d="M${s.x+86} 872H${s.x+238}" fill="none" stroke="${C.ochre}" stroke-width="3" marker-end="url(#arrow)"/>`);
}
svgParts.push(text(80,1132,'Reconstructed from the June 2020 newsletter, p08. Nodal points were handoffs.',18,{fill:C.muted}));

svgParts.push(line(80,1173,1320,1173));
svgParts.push(text(80,1226,'The value it aimed to create',33,{weight:700}));
svgParts.push(text(80,1282,'FOR FARMERS',20,{weight:700,spacing:1.1}));
svgParts.push(lines(80,1324,['Reach city demand with fewer','handling stages and intermediaries.'],26,38));
svgParts.push(text(755,1282,'FOR HOUSEHOLDS',20,{weight:700,spacing:1.1}));
svgParts.push(lines(755,1324,['Get fresh produce at home,','without a visit to the market.'],26,38));
svgParts.push(text(80,1410,'Value proposition from historical source accounts; not an audited impact measure.',18,{fill:C.muted}));

// Public and founder figures deliberately occupy separate bands.
svgParts.push(box(80,1454,1240,209,C.forest,10));
svgParts.push(text(113,1498,'PUBLIC SNAPSHOT  /  JUNE 2020',19,{fill:C.cream,weight:700,spacing:1.1}));
const pub=[{x:113,num:'8',label:'farmer tie-ups'},{x:511,num:'1,800+',label:'paid customers'},{x:943,num:'100+',label:'consumers daily'}];
pub.forEach(s=>{svgParts.push(text(s.x,1571,s.num,48,{weight:700,fill:C.cream}));svgParts.push(text(s.x,1613,s.label,24,{fill:C.cream}));});
svgParts.push(text(113,1644,'Startup Gujarat newsletter, p08 · programme-reported historical figures',17,{fill:C.sage}));

svgParts.push(box(80,1684,1240,209,C.paleOchre,10));
svgParts.push(text(113,1728,'LATER SCALE  /  FOUNDER RECORDS',19,{weight:700,spacing:1.1}));
svgParts.push(text(113,1801,'3,400',48,{weight:700}));
svgParts.push(text(113,1843,'B2C customers',24));
svgParts.push(text(594,1801,'3,000',48,{weight:700}));
svgParts.push(text(594,1843,'farmers reached',24));
svgParts.push(text(113,1874,'Measurement window not specified · separate from the June 2020 snapshot',17,{fill:C.muted}));

// A separate later market, not an invented branch in the documented 2020 route.
svgParts.push(icon('shop',119,1967));
svgParts.push(text(190,1949,'B2B EXPANSION  /  FOUNDER-REPORTED',19,{weight:700,spacing:.7}));
svgParts.push(text(190,1993,'Later served business buyers, including Marriott, Udaan and NinjaCart.',24));
svgParts.push(text(190,2028,'Client names come from founder career records; public contract evidence was not located.',18,{fill:C.muted}));

svgParts.push(line(80,2071,1320,2071));
svgParts.push(lines(80,2112,[
  'Sources: UrbanKhet company profile; Startup Gujarat, June 2020, p08;',
  'GUSEC founder interview, 3 June 2020; founder career records for later scale and B2B buyers.',
  'Historical founder portfolio · Collated 13 October 2026 · Original diagram',
],18,29,{fill:C.muted}));
svgParts.push('</svg>');
const svg=svgParts.join('\n');
await fs.mkdir(OUT,{recursive:true});
await fs.writeFile(path.join(OUT,'UrbanKhet-Infographic.svg'),svg);
await sharp(Buffer.from(svg)).png().toFile(path.join(OUT,'UrbanKhet-Infographic.png'));
await fs.copyFile(path.join(OUT,'UrbanKhet-Infographic.svg'),path.join(ROOT,'..','UrbanKhet-Infographic.svg'));
await fs.copyFile(path.join(OUT,'UrbanKhet-Infographic.png'),path.join(ROOT,'..','UrbanKhet-Infographic.png'));
console.log(JSON.stringify({width:W,height:H,svg:path.join(OUT,'UrbanKhet-Infographic.svg'),png:path.join(OUT,'UrbanKhet-Infographic.png')}));
