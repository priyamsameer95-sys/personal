#!/usr/bin/env python3
"""Build UrbanKhet's self-contained, offline portfolio entry from evidence metadata.

Run: python3 scripts/build_portfolio_entry.py
No external Python packages, fonts, scripts or network access are required.
"""
from __future__ import annotations

import html
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def read_json(path: str) -> dict:
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def main() -> None:
    research = read_json("source/source-index.json")
    manifest = read_json("source/studio/asset-manifest.json")
    sources = {s["id"]: s for s in research["sources"]}
    source_order = ["S01", "S02", "S12", "S11", "S08", "S03", "S04", "S05", "S06", "S07", "S15", "S09"]
    cards = []
    for item in manifest["assets"]:
        caption = {
            "urbankhet-superhero-market": "Campaign hero over market",
            "urbankhet-farmer-market": "Farmer and city market",
            "market-detail-09": "Vegetable cart detail",
            "market-detail-06": "Market truck detail",
            "market-detail-08": "Produce stall detail",
            "market-detail-07": "Farmer and household recipient",
            "customer-fresh-vegetables": "Customer with fresh vegetables",
            "delivery-straight-outta-khet": "Doorstep delivery illustration",
            "campaign-poster-01": "Service campaign poster",
            "campaign-poster-02": "COVID-era delivery campaign poster",
        }[item["slug"]]
        cards.append(
            '<figure class="campaign-card">'
            f'<a href="{esc(item["file"])}" aria-label="Open image: {esc(caption)}">'
            f'<img src="{esc(item["file"])}" alt="{esc(caption)}" '
            f'width="{item["width"]}" height="{item["height"]}" loading="lazy"></a>'
            f'<figcaption>{esc(caption)}</figcaption></figure>'
        )
    bibliography = []
    for sid in source_order:
        s = sources[sid]
        page_note = {
            "S08": " · Printed page 08",
            "S07": " · Physical pages 36, 62, 98 and 101; printed pages 21, 47, 83 and 86",
        }.get(sid, "")
        bibliography.append(
            '<li>'
            f'<a href="{esc(s["url"])}" target="_blank" rel="noopener noreferrer">'
            f'{esc(s["publisher"])} · {esc(s["title"])}</a>'
            f'<span>{esc(s["date"])}{esc(page_note)}</span></li>'
        )
    founder_metrics = {"figures": [
        {"value": "3,400", "label": "B2C customers"},
        {"value": "3,000", "label": "Farmers reached"},
        {"value": "35% → 10%", "label": "Wastage"},
    ]}
    short_summary = (
        "I founded UrbanKhet to bring food production and fresh produce closer to urban customers. "
        "The venture began with urban farming solutions and evolved into a farm-to-city supply operation. "
        "During COVID-19, we built a practical link between farms and households. UrbanKhet's value came from "
        "coordinating supply, handling and last-mile access: helping growers reach buyers while making "
        "fresh produce easier for households to obtain."
    )

    def metric_html(panel: dict) -> str:
        return "".join(
            f'<div class="metric"><strong>{esc(m["value"])}</strong><span>{esc(m["label"])}</span></div>'
            for m in panel["figures"]
        )

    document = '''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="UrbanKhet: Priyam Sameer's historical founder case study, from urban farming to farm-to-city produce supply. Original infographic, campaign archive and dated evidence.">
  <title>UrbanKhet — Priyam Sameer's founder portfolio</title>
  <style>
    :root{--cream:#f5f2e7;--paper:#fffdf6;--forest:#163e32;--sage:#dce7d5;--muted:#475b4b;--line:#c7d3bd;--accent:#cbdc76;--radius:20px}
    *{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--cream);color:var(--forest);font:18px/1.6 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
    a{color:inherit;text-underline-offset:4px}a:hover{text-decoration-thickness:2px}a:focus-visible{outline:3px solid #86641e;outline-offset:5px}img{max-width:100%;display:block;height:auto}
    .wrap{width:min(1180px,calc(100% - 64px));margin:auto}.skip{position:absolute;left:12px;top:-100px;background:var(--forest);color:#fff;padding:8px 16px;z-index:10}.skip:focus{top:12px}
    header{border-bottom:1px solid var(--line)}.topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:22px 0}.brand{font-size:22px;letter-spacing:-.6px;font-weight:750;text-decoration:none;display:flex;align-items:center;gap:12px}.brand small{font-size:15px;font-weight:450;display:block;letter-spacing:0;color:var(--muted)}.company-mark{width:84px;height:auto;background:white;border-radius:8px}nav{display:flex;gap:22px;flex-wrap:wrap;font-size:16px}
    .eyebrow{font-size:14px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin:0 0 18px}.hero{display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center;padding:66px 0 60px}.hero h1{font-family:Georgia,"Times New Roman",serif;font-weight:400;font-size:clamp(38px,4.4vw,63px);line-height:1.07;letter-spacing:-1.8px;margin:0 0 24px}.hero p{margin:0 0 22px}.hero figure{margin:0}.hero img{border-radius:var(--radius);aspect-ratio:3/2;object-fit:cover;border:1px solid var(--line)}figcaption,.caption{font-size:15px;line-height:1.55;color:var(--muted);margin:12px 0 0}.meta{display:flex;gap:9px;flex-wrap:wrap}.meta span{background:var(--sage);padding:6px 12px;border-radius:99px;font-size:14px;line-height:1.3}.actions{display:flex;gap:12px;flex-wrap:wrap;margin:28px 0 0}.button{background:var(--forest);color:var(--paper);padding:11px 18px;border-radius:8px;font-size:16px;font-weight:650;text-decoration:none}.button.secondary{background:transparent;color:var(--forest);border:1px solid var(--forest)}
    section{padding:48px 0;border-top:1px solid var(--line)}h2{font-family:Georgia,"Times New Roman",serif;font-weight:400;font-size:clamp(30px,3vw,42px);line-height:1.2;letter-spacing:-.8px;margin:0 0 24px}h3{font-size:21px;line-height:1.3;margin:0 0 14px}.section-intro{max-width:760px;margin:0 0 28px}.phase-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.phase{background:var(--paper);padding:28px;border:1px solid var(--line);border-radius:var(--radius)}.phase .number{font-size:14px;font-weight:700;color:var(--muted);display:block;margin-bottom:14px}.phase p{margin:0}.phase small{display:block;font-size:15px;color:var(--muted);margin-top:20px}.infographic{margin:0;background:var(--paper);padding:12px;border:1px solid var(--line);border-radius:var(--radius)}.infographic img{width:100%;border-radius:10px}.infographic figcaption{padding:0 12px 8px}.infographic a{display:block}.file-links{display:flex;gap:20px;flex-wrap:wrap;margin-top:18px;font-size:16px}
    .metric-panels{display:grid;grid-template-columns:1fr 1fr;gap:22px}.metric-panel{background:var(--sage);padding:30px;border-radius:var(--radius)}.metric-panel.founder{background:var(--paper);border:1px solid var(--line)}.metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:25px 0 20px}.metric strong{display:block;font-size:clamp(24px,2.8vw,35px);font-weight:750;line-height:1.2;letter-spacing:-1px}.metric span{display:block;font-size:15px;line-height:1.4;margin-top:9px}.metric-panel .caption{margin:0}.split{display:grid;grid-template-columns:1fr 1fr;gap:50px}.summary{font-size:21px;line-height:1.6;margin:0}.ownership{padding:0 0 0 22px;margin:0}.ownership li{margin:0 0 12px}.recognition{background:var(--sage);padding:25px 30px;border-radius:var(--radius);margin-top:28px}.recognition p{margin:0;font-size:17px}
    .campaign-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}.campaign-card{margin:0;padding:12px 12px 18px;background:var(--paper);border:1px solid var(--line);border-radius:14px}.campaign-card img{width:100%;height:280px;object-fit:contain;background:#eef0df;border-radius:7px}.campaign-card figcaption{padding:0 4px;font-size:15px;line-height:1.45}.credit{font-size:15px;margin:26px 0 0;max-width:900px;color:var(--muted)}details{background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:22px 26px}summary{cursor:pointer;font-size:20px;font-weight:650}summary::marker{color:var(--forest)}.sources{margin:20px 0 0;padding-left:24px}.sources li{margin-bottom:18px;font-size:16px;line-height:1.5}.sources span{display:block;margin-top:4px;font-size:15px;color:var(--muted)}.note{font-size:15px;color:var(--muted);margin:22px 0 0}.downloads{display:flex;gap:15px;flex-wrap:wrap}.downloads a{padding:13px 19px;border:1px solid var(--forest);border-radius:8px;font-weight:650;font-size:16px;text-decoration:none}.downloads a:hover{background:var(--sage)}footer{padding:32px 0;border-top:1px solid var(--line);font-size:15px;color:var(--muted)}footer .wrap{display:flex;justify-content:space-between;gap:24px;flex-wrap:wrap}
    @media(max-width:1000px){.hero{gap:30px}.phase{padding:22px}.metric-panels{grid-template-columns:1fr}.campaign-card img{height:240px}}
    @media(max-width:760px){body{font-size:17px}.wrap{width:calc(100% - 36px)}.topbar{align-items:flex-start;flex-direction:column;gap:16px}nav{gap:16px}.hero{grid-template-columns:1fr;padding:40px 0;gap:30px}.hero h1{letter-spacing:-1px}.hero img{aspect-ratio:auto}section{padding:34px 0}.phase-grid,.split{grid-template-columns:1fr;gap:18px}.metric-panel{padding:24px}.campaign-grid{grid-template-columns:repeat(2,1fr);gap:14px}.campaign-card{padding:9px}.campaign-card img{height:200px}.campaign-card figcaption{font-size:14px}.summary{font-size:19px}.recognition{padding:22px}.metrics{gap:12px}details{padding:20px}.sources{padding-left:20px}}
    @media(max-width:420px){.campaign-grid{grid-template-columns:1fr}.campaign-card img{height:280px}.metrics{grid-template-columns:1fr;gap:18px}.metric{display:grid;grid-template-columns:120px 1fr;align-items:center;gap:12px}.metric span{margin:0}.metric strong{font-size:28px}}
    @media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}@media print{header nav,.actions,.downloads{display:none}body{background:white;color:black}.wrap{width:100%}.hero{padding:20px 0}.phase-grid{display:block}.phase{break-inside:avoid;margin:10px 0}.campaign-grid{grid-template-columns:repeat(3,1fr)}section{break-inside:avoid}.campaign-card img{height:150px}details{border:0}details>*{display:block}}
  </style>
</head>
<body>
<a class="skip" href="#main">Skip to case study</a>
<header><div class="wrap topbar"><a class="brand" href="#main"><img class="company-mark" src="assets/UrbanKhet-Original-Logo.png" width="467" height="213" alt="UrbanKhet original logo"><span>UrbanKhet<small>Priyam Sameer · Founder portfolio</small></span></a><nav aria-label="Case study navigation"><a href="#model">Model</a><a href="#evidence">Evidence</a><a href="#campaign">Campaign</a><a href="#downloads">Files</a></nav></div></header>
<main id="main" class="wrap">
<div class="hero">
  <div><p class="eyebrow">Historical founder venture · Ahmedabad</p><h1>Building a shorter route<br>from farms to cities.</h1>
  <p>UrbanKhet brought food production and fresh produce closer to urban customers: first through urban farming, then through a farm-to-city supply operation.</p>
  <div class="meta"><span>0→1 venture</span><span>Supply operations</span><span>Household fulfilment</span><span>Founder leadership</span></div>
  <p class="caption">2018–2021 in founder career records. Public operating evidence dates to 2020–2021; this is a historical case study.</p>
  <div class="actions"><a class="button" href="UrbanKhet-Portfolio-Case-Study.pdf">Read the case study</a><a class="button secondary" href="#infographic">Explore the model</a></div></div>
  <figure><a href="assets/UrbanKhet-Original-Interpretation.png"><img src="assets/UrbanKhet-Original-Interpretation.png" alt="Original editorial illustration interpreting the connection between farms, coordinated produce distribution and urban households."></a><figcaption>Original editorial illustration created for this portfolio; a conceptual interpretation, not a photograph of the operation.</figcaption></figure>
</div>
<section id="model"><p class="eyebrow">An evolving service</p><h2>One purpose. Three business phases.</h2>
<div class="phase-grid">
  <article class="phase"><span class="number">01 · EARLY MODEL</span><h3>Bring farming into the city</h3><p>Urban farming assistance and microfarm concepts connected urban space, investment and technical farming capability.</p><small>Company and incubator descriptions; the exact transition date is undocumented.</small></article>
  <article class="phase"><span class="number">02 · DOCUMENTED IN 2020</span><h3>Bring produce to households</h3><p>A fresh-produce supply operation connected existing growers with urban household demand during COVID-19.</p><small>The original infographic shows the documented fulfilment route.</small></article>
  <article class="phase"><span class="number">03 · FOUNDER-REPORTED</span><h3>Expand into B2B supply</h3><p>Later operations served organisational buyers. Founder records name Marriott, Udaan and NinjaCart.</p><small>Public sources here do not establish dates, contract terms or revenue.</small></article>
</div></section>
<section id="infographic"><p class="eyebrow">Original business interpretation</p><h2>The product was the whole service.</h2><p class="section-intro">The value came from coordinating supply, preparation and delivery: a route to urban demand for growers, and easier access to produce for households.</p>
<figure class="infographic"><a href="assets/UrbanKhet-Infographic.svg" aria-label="Open full-size UrbanKhet business-model infographic"><img src="assets/UrbanKhet-Infographic.png" alt="UrbanKhet infographic showing the early urban-farming model, the documented farm-to-household fulfilment route, founder-reported B2B expansion, responsibilities and separately qualified metrics." loading="lazy"></a><figcaption>Original infographic, reconstructed from dated public reporting and labelled founder records. Open the image for full-size detail.</figcaption></figure>
<div class="file-links"><a href="assets/UrbanKhet-Infographic.svg" download>Download editable SVG</a><a href="assets/UrbanKhet-Infographic.png" download>Download PNG</a></div></section>
<section id="evidence"><p class="eyebrow">Scale with provenance</p><h2>Two snapshots, kept distinct.</h2>
<div class="metric-panels"><article class="metric-panel"><h3>Published operating snapshot · June 2020</h3><p>See the dated June 2020 operational snapshot in the <a href="#infographic">infographic</a>.</p><p class="caption">Gujarat startup newsletter, page 08. Reported from nodal-institution inputs; these figures describe that period and are not independently audited.</p></article>
<article class="metric-panel founder"><h3>Later scale · Founder records</h3><div class="metrics">__FOUNDER_METRICS__</div><p class="caption">Customer and farmer reach: founder account, 26 February 2025. Wastage: career-record claim. Measurement windows and methods are unavailable; farmer reach is distinct from active supplier tie-ups.</p></article></div>
<div class="recognition"><p><strong>Institutional recognition:</strong> GUSEC Rise Award, event 26 February 2021; GUSEC TIDE 2.0 portfolio; IIMA Ventures’ official investment portfolio. The IIMA listing gives no company-specific investment amount, date or round.</p></div></section>
<section id="founder"><p class="eyebrow">Founder ownership</p><div class="split"><div><h2>From problem to operating business.</h2><p class="summary">__SHORT_SUMMARY__</p></div><div><h3>What I owned</h3><ul class="ownership"><li>Problem selection and service direction.</li><li>Grower relationships and the supply network.</li><li>COVID-era pilot coordination with Ahmedabad’s municipal administration.</li><li>A service connecting farm-side preparation, city distribution and last-mile delivery.</li><li>Business-segment and unit-economics development with incubator mentoring.</li></ul><p class="caption">Founder ownership is a synthesis of institutional reporting and career records. The detailed document explains the evidence and limits of each claim.</p><p class="caption">The founder reports winding down after the second COVID wave.</p></div></div></section>
<section id="campaign"><p class="eyebrow">Historical brand archive · 2021 campaign</p><h2>How the offer was communicated.</h2><p class="section-intro">These are original campaign illustrations and published poster stills from Studio Sorted’s UrbanKhet case study.</p>
<div class="campaign-grid">__CAMPAIGN_CARDS__</div>
<p class="credit"><strong>Creative attribution:</strong> Studio Sorted. Creative direction: Abhishek Durani. Graphic design and illustration: Ritam Mukherjee, Ishita Poddar and Tanmay Acharya. Design management: Netra Ajjampur. Campaign images remain attributed to their original creators; the source page states no reuse licence. <a href="https://www.studiosorted.com/work/urbankhet" target="_blank" rel="noopener noreferrer">View the original case</a>.</p></section>
<section id="sources"><p class="eyebrow">Source trail</p><h2>A clearer story from fragmented records.</h2><details><summary>References, dates and access limits</summary><ol class="sources">__BIBLIOGRAPHY__</ol><p class="note">Sources checked 13 October 2026. The four supplied URLs were separated from the concatenated link. Instagram and F6S provided no substantive accessible content. The detailed document records the full 15-source investigation, discrepancies and claim qualifications.</p></details></section>
<section id="downloads"><p class="eyebrow">Portfolio files</p><h2>Read, reuse and adapt.</h2><div class="downloads"><a href="UrbanKhet-Portfolio-Case-Study.pdf">Case study · PDF</a><a href="UrbanKhet-Portfolio-Case-Study.docx">Editable case · DOCX</a><a href="portfolio-case-copy.txt">Portfolio copy · TXT</a><a href="portfolio-short-summary.txt">Short summary · TXT</a><a href="README.txt">Archive guide</a></div></section>
</main><footer><div class="wrap"><span>UrbanKhet · Historical founder case study</span><span>Editorial synthesis prepared 13 October 2026</span></div></footer>
</body></html>
'''
    replacements = {
        "__FOUNDER_METRICS__": metric_html(founder_metrics),
        "__SHORT_SUMMARY__": esc(short_summary),
        "__CAMPAIGN_CARDS__": "\n".join(cards),
        "__BIBLIOGRAPHY__": "\n".join(bibliography),
    }
    for key, value in replacements.items():
        document = document.replace(key, value)
    (ROOT / "index.html").write_text(document, encoding="utf-8")
    guide = """URBANKHET — FOUNDER PORTFOLIO ARCHIVE
Prepared for Priyam Sameer on 13 October 2026

OPEN THE PORTFOLIO ENTRY
Extract the entire ZIP to one folder, then open index.html in a web browser.
Keep its folders together: image and document links use relative paths.
The page uses local files and system fonts. Internet access is required only
when you choose an external source link. No videos are included.

MAIN FILES
index.html — responsive offline portfolio entry with a campaign gallery,
dated evidence panels, source links and downloadable files.
UrbanKhet-Portfolio-Case-Study.pdf — detailed, designed case study and evidence.
UrbanKhet-Portfolio-Case-Study.docx — editable document counterpart.
portfolio-case-copy.txt — longer first-person text for a portfolio page.
portfolio-short-summary.txt — compact first-person portfolio description.
assets/UrbanKhet-Infographic.svg — editable vector business-model infographic.
assets/UrbanKhet-Infographic.png — raster version of the same infographic.
assets/UrbanKhet-Original-Interpretation.png — original editorial illustration;
this is conceptual artwork, not a photograph or an operational record.
assets/UrbanKhet-Original-Logo.png — original company logo preserved from
the IIMA Ventures official portfolio listing.
assets/studio/ — 10 original Studio Sorted campaign images/poster stills.
source/ — curated reference index and campaign-asset metadata/provenance.
scripts/ — reproducible generators and the project-source asset scraper.

HOW TO READ THE CASE
The sources describe different stages of a historical venture: early urban
farming, a June 2020 farm-to-household supply operation and later
founder-reported B2B expansion. The exact pivot date
is not documented. The 2018–2021 operating period and winding-down account
come from founder career records, not a verified legal-status lookup.

See the dated June 2020 operational snapshot in the infographic. These are
newsletter-reported figures based on nodal-institution inputs, not an audit.

Later founder records: 3,400 B2C customers, 3,000 farmers reached and wastage
from 35% to 10%. Measurement periods and methods are unavailable. Do not
equate farmer reach with active supplier relationships or blend the two
snapshots into one dated outcome.

Recognition is named precisely: GUSEC Rise Award (event 26 February 2021),
GUSEC TIDE 2.0 portfolio and IIMA Ventures' official investment portfolio.
The IIMA listing does not state an investment amount, date or round.
No current ordering service, legal status, pricing, profitability or software
feature is asserted. Instagram and F6S did not yield substantive content.

CREATIVE CREDIT
Studio Sorted produced the historical campaign images. Creative direction:
Abhishek Durani. Graphic design and illustration: Ritam Mukherjee, Ishita
Poddar and Tanmay Acharya. Design management: Netra Ajjampur.
Their source page does not state a reuse licence. Preserve attribution.
The separately labelled infographic and editorial illustration were created
for this portfolio; they are not the original commissioned campaign.

SOURCE URLS — CORRECTED FROM THE CONCATENATED LINK
https://www.studiosorted.com/work/urbankhet
https://www.linkedin.com/company/khet-inc/
https://www.instagram.com/urbankhet/
https://www.f6s.com/member/priyamsameer1

REBUILD THE ENTRY
From the extracted folder, run:
python3 scripts/build_portfolio_entry.py
The generator reads JSON metadata and writes index.html and this README.
Python's standard library is sufficient; no network access is used.
"""
    (ROOT / "README.txt").write_text(guide, encoding="utf-8")
    print(f"Created {ROOT / 'index.html'}")
    print(f"Created {ROOT / 'README.txt'}")


if __name__ == "__main__":
    main()
