#!/usr/bin/env python3
"""Build the UrbanKhet founder case study from a deliberately reconciled narrative.

Run with the Codex primary Python runtime. Export with the bundled document
renderer so the PDF and editable DOCX share the same pagination and content.
"""
import json
import re
import shutil
from pathlib import Path
from PIL import Image
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

BASE = Path(__file__).resolve().parents[1]
ROOT = BASE.parent
OUT = ROOT / 'UrbanKhet-Portfolio-Case-Study.docx'
QA = BASE / 'qa' / 'document'
QA.mkdir(parents=True, exist_ok=True)

CONTENT = {
    'title': 'UrbanKhet founder case study',
    'author': 'Priyam Sameer',
    'date': '13 October 2026',
    'purpose': 'A historical portfolio account of venture creation, business evolution and fresh produce supply operations in Ahmedabad.',
    'pages': [
        {
            'heading': 'UrbanKhet founder case study',
            'blocks': [
                {'type': 'subtitle', 'text': 'Urban farming and fresh produce supply in Ahmedabad'},
                {'type': 'byline', 'text': 'Priyam Sameer   Founder and CEO   2018 to 2021'},
                {'type': 'p', 'text': 'I founded UrbanKhet to bring food production and fresh produce closer to city demand. The venture began with urban farming solutions and developed into a fresh produce supply business serving households and business buyers. I worked on the offer, farmer relationships, fulfilment and the economics of moving perishable goods.'},
                {'type': 'figure', 'asset': 'assets/UrbanKhet-Original-Interpretation.png', 'max_width': 7.05, 'max_height': 3.98, 'alt': 'Original conceptual illustration of growers preparing produce and a delivery route into a city neighbourhood.', 'caption': 'Original conceptual illustration created for this portfolio. It visualises the business idea and is not a photograph, an archived operating site or an original company campaign.'},
                {'type': 'h2', 'text': 'What the venture demonstrates'},
                {'type': 'p', 'text': 'UrbanKhet is a concrete example of my experience building a business from zero and connecting customer needs with physical operations. Its value depended on coordinating people and goods: finding a route to buyers for growers and making fresh produce easier for urban customers to obtain. This case explains the business stages, my founder scope and the delivery model, then separates dated public evidence from the later results I reported in career accounts.'},
                {'type': 'small', 'text': 'Historical venture. The working period and CEO title follow founder career records. Public sources document operations and support in 2020 and 2021. Source numbers refer to the links on the final page.'},
            ]
        },
        {
            'heading': 'Business evolution and customer value',
            'blocks': [
                {'type': 'p', 'text': 'The early proposition was to use underutilised urban space for food production. The surviving company profile lists a 2018 founding year, while GUSEC records describe microfarms and a model involving a space owner, an investor and a technical operator. This was the origin of the venture, rather than a complete description of its later activities. [1, 4]'},
                {'type': 'p', 'text': 'By June 2020, the produce delivery operation was publicly documented. [3] I describe the evolution as a shift from creating production near city customers to helping existing growers reach city demand. That interpretation connects the two business stages; the exact date and internal decision process of the pivot are not established in the public archive.'},
                {'type': 'h2', 'text': 'Value for each participant'},
                {'type': 'table', 'widths': [1.15, 2.25, 3.6], 'headers': ['Participant', 'Need', 'UrbanKhet proposition'], 'rows': [
                    ['Household', 'Access to essential fresh produce', 'Doorstep delivery that reduced the need to visit a market during the pandemic. [7]'],
                    ['Farmer', 'A practical route to urban buyers', 'A customer connection and farm preparation within a coordinated distribution model. [2]'],
                    ['Business buyer', 'A workable source of produce', 'A later B2B supply offer whose value depended on usable quality and fulfilment. Founder reported.'],
                ]},
                {'type': 'p', 'text': 'These needs required different promises. Household convenience depended on completing an individual delivery. A business buyer would evaluate supply in the context of its own operation. I therefore frame B2B expansion as a change in customer requirements, rather than treating every buyer as the same demand channel. This is a business interpretation; contract terms and service specifications are not preserved in the available material.'},
                {'type': 'h2', 'text': 'Historical milestones'},
                {'type': 'table', 'widths': [1.2, 4.7, 1.1], 'headers': ['Period', 'Milestone', 'Basis'], 'rows': [
                    ['2018', 'Urban farming origin', 'Profile [1]'],
                    ['June 2020', 'Farm to household operation documented', 'Report [3]'],
                    ['2020 to 2021', 'Continuity Accelerator and unit economics mentoring', 'GUSEC [4]'],
                    ['26 Feb 2021', 'GUSEC Rise Award for Priyam Sameer', 'GUSEC [5]'],
                    ['Later stage', 'B2B supply and eventual winding down', 'Founder'],
                ]},
                {'type': 'small', 'text': 'Venture founding, a creative project year and legal incorporation are different dates. This case does not assign a statutory incorporation date or an exact pivot month.'},
            ]
        },
        {
            'heading': 'UrbanKhet delivery model',
            'blocks': [
                {'type': 'figure', 'asset': 'assets/UrbanKhet-Infographic.png', 'max_width': 7.05, 'max_height': 8.1, 'alt': 'Original infographic explaining the historical delivery model and a dated operating snapshot.', 'caption': 'Original editorial infographic based on the June 2020 newsletter, printed page 08. [3]'},
            ]
        },
        {
            'heading': 'Building and operating the service',
            'blocks': [
                {'type': 'h2', 'text': 'My founder scope'},
                {'type': 'p', 'text': 'As founder and CEO, I owned the business proposition, customer acquisition, farmer network, fulfilment, fundraising and P&L. Those responsibilities were connected. A customer offer was only useful if the supply side could support it, and expansion required enough operating discipline to meet the promise. I set the venture direction and worked with the team and partners to carry it out.'},
                {'type': 'p', 'text': 'During the lockdown, I worked on supplier relationships and outreach to Ahmedabad Municipal Corporation. The GUSEC interview and annual report document municipal cooperation and mentoring on unit economics and business segments. This was the work of turning a market access problem into an operating service, obtaining local support and evaluating a commercial model. [2, 4]'},
                {'type': 'h2', 'text': 'Where coordination created value'},
                {'type': 'p', 'text': 'The diagram on page three identifies the physical route. [3] My operational interpretation concerns accountability: each transfer needs a clear owner and an agreed definition of readiness. When those are explicit, a team can identify where an incomplete task originated and who should resolve it.'},
                {'type': 'p', 'text': 'I see product work in these operating choices: deciding who the customer is, what the service must deliver and where responsibility changes hands. In UrbanKhet, the service depended on a physical network of people and produce. This case describes that operating model and the founder decisions around it.'},
                {'type': 'h2', 'text': 'Tradeoffs in the model'},
                {'type': 'table', 'widths': [1.9, 2.7, 2.4], 'headers': ['Decision area', 'Why it matters', 'Retrospective lesson'], 'rows': [
                    ['Preparation at source', 'More preparation before the city handoff can simplify later handling.', 'Define readiness before transferring responsibility.'],
                    ['Perishable inventory', 'Unsold or poorly handled goods can lose value quickly.', 'Assess growth with waste and fulfilment costs.'],
                    ['Households and B2B', 'Order patterns and acceptance needs can differ by buyer.', 'Design the offer around the customer segment.'],
                    ['Delivery density', 'Scattered orders can increase effort per delivery.', 'Evaluate demand alongside the cost to serve it.'],
                ]},
                {'type': 'small', 'text': 'The tradeoffs are an editorial interpretation of a perishable goods business. They are not measured route savings, proof of a specific operating policy or a claim of profitability.'},
            ]
        },
        {
            'heading': 'Customers and operating results',
            'blocks': [
                {'type': 'p', 'text': 'Two evidence levels describe the venture. The public snapshot captures an early point in its operation. My later career account supplies broader reach and B2B relationships. I keep them separate because farmer tie-ups, farmers reached and customers are different measures.'},
                {'type': 'h2', 'text': 'Published operating snapshot'},
                {'type': 'p', 'text': 'The infographic preserves the June 2020 reported figures. [3] They describe an early snapshot; my later reach figures below use founder career records.'},
                {'type': 'h2', 'text': 'Later founder reported reach'},
                {'type': 'table', 'widths': [2.0, 1.3, 3.7], 'headers': ['Measure', 'Reported result', 'Meaning and scope'], 'rows': [
                    ['B2C customers', '3,400', 'Later reach reported in my career account; the measurement period was not supplied.'],
                    ['Farmer reach', '3,000', 'Reported farmer network reach; not a verified count of recurring active suppliers.'],
                    ['B2B customers', 'Named accounts', 'Marriott, Udaan and NinjaCart in founder career records; contract scope not preserved.'],
                ]},
                {'type': 'p', 'text': 'B2B supply widened the use of the network beyond household deliveries. It also introduced a different way to assess the service: a business buyer needed produce that worked for its own operation. Serving these buyers meant considering supply in that context. The named accounts describe historical customer relationships, with contract scope and value left unspecified.'},
                {'type': 'h2', 'text': 'Institutional support and recognition'},
                {'type': 'p', 'text': 'GUSEC publicly identifies me as UrbanKhet\'s founder. Its TIDE 2.0 programme page includes the venture in the MeitY supported portfolio. The GUSEC Rise Award was conferred on 26 February 2021 and announced on 10 March. [5, 6]'},
                {'type': 'p', 'text': 'UrbanKhet is also listed in the official IIMA Ventures investment portfolio. The portfolio describes ventures that received capital and in which IIMA holds a stake. This supports describing UrbanKhet as IIMA Ventures backed, without assigning an investment date, round or amount. The exact incubation programme in my founder history remains separately reported. [8]'},
                {'type': 'small', 'text': 'Reported counts are not combined to calculate growth, conversion, retention or active supply. No revenue, GMV, margin or municipal procurement value is claimed here.'},
            ]
        },
        {
            'heading': 'Communicating the customer offer',
            'blocks': [
                {'type': 'p', 'text': 'The Studio Sorted project gives the business a clear customer facing expression. Its 2021 campaign describes fresh fruits and vegetables reaching the doorstep and connects pandemic household access with farmers seeking buyers. That creative record helps explain the produce delivery stage without supplying operational performance data. [7]'},
                {'type': 'figure', 'asset': 'assets/studio/delivery-straight-outta-khet.webp', 'max_width': 7.05, 'max_height': 3.55, 'alt': 'Historical UrbanKhet campaign illustration showing a delivery worker bringing produce to a doorstep.', 'caption': 'Historical commissioned UrbanKhet campaign artwork, 2021. Credit: Studio Sorted. Creative direction: Abhishek Durani. Graphic design and illustration: Ritam Mukherjee, Ishita Poddar and Tanmay Acharya. Design management: Netra Ajjampur. [7]'},
                {'type': 'h2', 'text': 'What the brand had to make clear'},
                {'type': 'p', 'text': 'A produce business has to communicate an offer customers can understand before placing an order. Doorstep access gives the household a concrete reason to consider the service. The farmer side needs a different explanation: how produce can reach a buyer. I use that distinction to describe UrbanKhet as a coordinated supply business, rather than allowing the earlier microfarm description and later campaign to compete as two unrelated identities.'},
                {'type': 'h2', 'text': 'The new portfolio graphics'},
                {'type': 'p', 'text': 'The cover illustration is an original visual interpretation of the venture. The infographic on page three is a precise explanation of the published delivery route and its dated early snapshot. Their purpose is to make the business understandable at a glance. They are new portfolio graphics, distinct from the historical commissioned campaign shown above.'},
                {'type': 'small', 'text': 'The artwork illustrates the offer. It does not establish organic certification, food safety certification, guaranteed delivery times or an independently measured increase in farmer income.'},
            ]
        },
        {
            'heading': 'Founder reflection and portfolio introduction',
            'blocks': [
                {'type': 'h2', 'text': 'Winding down the venture'},
                {'type': 'p', 'text': 'I wound down UrbanKhet after the second COVID wave and released a 20 person team, as recorded in my founder account. This case concerns that historical operation. Surviving social profiles and campaign pages remain useful evidence of the venture; they do not establish its current legal or operating status.'},
                {'type': 'p', 'text': 'I do not present the closure as evidence that the customer problem disappeared. My retrospective lesson is to assess demand together with the ability to fulfil it economically. A service can be useful while remaining exposed to supply, handling and delivery constraints. That discipline is relevant to later work in commerce and agriculture, where product choices must survive contact with real operations.'},
                {'type': 'h2', 'text': 'What I carry into product leadership'},
                {'type': 'p', 'text': 'This venture gave me founder accountability for the whole service. It taught me to distinguish a broad problem from a specific offer and to understand which part of the chain I could influence. The move from urban farming towards produce supply changed the work that created value: the focus became how goods could reach demand, rather than only where they could be grown.'},
                {'type': 'p', 'text': 'I also learned to make roles and handoffs explicit. A promise made to a buyer depends on the person preparing the order, the person moving it and the person completing delivery. That is why I explain the operating route before discussing scale. The numbers are useful only when the underlying service and their definitions are clear.'},
                {'type': 'h2', 'text': 'Portfolio opening'},
                {'type': 'p', 'text': 'I founded UrbanKhet in Ahmedabad, beginning with urban farming solutions and evolving into fresh produce supply. I owned the business proposition, acquisition, farmer network, fulfilment and P&L with the team and partners. Public records document our COVID era household delivery model and GUSEC support. My later founder account reports 3,400 B2C customers, a reach of 3,000 farmers and B2B supply to Marriott, Udaan and NinjaCart. The experience built my ability to take a service from zero, coordinate physical operations and evaluate customer value against the economics of fulfilment. I wound down the venture after the second COVID wave. This is a historical case study; later operating results are founder reported.'},
            ]
        },
        {
            'heading': 'Evidence and source notes',
            'blocks': [
                {'type': 'p', 'text': 'Public institutional records establish the early proposition, the dated delivery operation, GUSEC support and the Rise Award. Later reach, named B2B buyers, the CEO title and closure are founder accounts. New visuals explain the model; historical campaign artwork retains its Studio Sorted credit.'},
                {'type': 'table', 'widths': [2.4, 4.6], 'headers': ['Record requiring context', 'Treatment in this case'], 'rows': [
                    ['56 terrace units', 'Earlier founder career record; dates and measurement detail unavailable. Not used as a headline result.'],
                    ['Wastage from 35% to 10%', 'Earlier founder record; denominator and period unavailable. No saving or relative reduction inferred.'],
                    ['Peak team of 28', 'Prior career context with uncertain provenance. Excluded from the operating results.'],
                    ['Farmer earnings claim', 'A 2020 interview includes a 20% to 50% claim without a study design. Excluded from headline impact. [2]'],
                    ['IIMA Ventures backing', 'Publicly confirmed by the official investment portfolio listing. Exact incubation programme remains founder reported. [8]'],
                ]},
                {'type': 'h2', 'text': 'Sources'},
                {'type': 'source', 'number': 1, 'label': 'UrbanKhet company profile on LinkedIn', 'url': 'https://www.linkedin.com/company/khet-inc/', 'note': 'Undated. Founding year and early proposition.'},
                {'type': 'source', 'number': 2, 'label': 'GUSEC founder interview', 'url': 'https://gusec.edu.in/2020/06/03/urbankhet/', 'note': '3 June 2020. Founder and pandemic operations.'},
                {'type': 'source', 'number': 3, 'label': 'Startup Gujarat June 2020 newsletter', 'url': 'https://startupdemo.orpgujarat.com/files/2021/1/0ed7d91a-0cd7-4829-ad13-6c4df8a9ef5d_Newsletter_Startup%20ecosystem%20in%20Gujarat_June%202020.pdf', 'note': 'Printed page 08.'},
                {'type': 'source', 'number': 4, 'label': 'GUSEC Annual Snapshot 2020 to 2021', 'url': 'https://gusec.edu.in/wp-content/uploads/2023/08/GUSEC-ANNUAL-SNAPSHOT-2020-21.pdf', 'note': 'Printed pages 21, 47, 83 and 86; physical pages 36, 62, 98 and 101.'},
                {'type': 'source', 'number': 5, 'label': 'GUSEC annual awards announcement', 'url': 'https://gusec.edu.in/2021/03/10/gusec-annual-awards-2021/', 'note': '10 March 2021. Event held 26 February 2021.'},
                {'type': 'source', 'number': 6, 'label': 'GUSEC TIDE 2.0 portfolio', 'url': 'https://gusec.edu.in/tide/', 'note': 'Programme association, without a company grant amount.'},
                {'type': 'source', 'number': 7, 'label': 'Studio Sorted UrbanKhet project', 'url': 'https://www.studiosorted.com/work/urbankhet', 'note': 'Stated project year 2021. Historical artwork and credits.'},
                {'type': 'source', 'number': 8, 'label': 'IIMA Ventures investment portfolio', 'url': 'https://iimaventures.com/portfolio/', 'note': 'UrbanKhet logo card and investment portfolio scope.'},
                {'type': 'h2', 'text': 'Other supplied links'},
                {'type': 'link', 'label': 'UrbanKhet Instagram profile', 'url': 'https://www.instagram.com/urbankhet/'},
                {'type': 'link', 'label': 'Priyam Sameer F6S profile', 'url': 'https://www.f6s.com/member/priyamsameer1'},
                {'type': 'small', 'text': 'No substantive claims were drawn from the Instagram login shell or unavailable F6S profile. Public pages were reviewed on 13 October 2026. Founder career accounts provide the separately identified later results.'},
            ]
        },
    ],
    'source_derivation_note': 'Public-source wording is deliberately brief. The business reasoning and lessons are labelled interpretation, and later operating results use user-supplied founder accounts. The original infographic is placed once.'
}

def set_font(run, size=None, bold=None):
    run.font.name = 'Arial'
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    run.font.color.rgb = RGBColor(0, 0, 0)

def hyperlink(p, text, url, size=8.8):
    rel = p.part.relate_to(url, RT.HYPERLINK, is_external=True)
    h = OxmlElement('w:hyperlink')
    h.set(qn('r:id'), rel)
    r = OxmlElement('w:r')
    pr = OxmlElement('w:rPr')
    font = OxmlElement('w:rFonts')
    font.set(qn('w:ascii'), 'Arial'); font.set(qn('w:hAnsi'), 'Arial')
    pr.append(font)
    color = OxmlElement('w:color'); color.set(qn('w:val'), '000000'); pr.append(color)
    sz = OxmlElement('w:sz'); sz.set(qn('w:val'),str(int(size*2))); pr.append(sz)
    u = OxmlElement('w:u'); u.set(qn('w:val'), 'single'); pr.append(u)
    r.append(pr)
    t = OxmlElement('w:t'); t.text = text; r.append(t)
    h.append(r); p._p.append(h)

def style_table(table, widths):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for c, width in zip(table.columns, widths):
        c.width = Inches(width)
    pr = table._tbl.tblPr
    borders = OxmlElement('w:tblBorders')
    for side in ('top','left','bottom','right','insideH','insideV'):
        e = OxmlElement('w:'+side); e.set(qn('w:val'),'single'); e.set(qn('w:sz'),'4'); e.set(qn('w:color'),'D9D9D9'); borders.append(e)
    pr.append(borders)
    for ri, row in enumerate(table.rows):
        trPr = row._tr.get_or_add_trPr()
        no_split = OxmlElement('w:cantSplit'); trPr.append(no_split)
        if ri == 0:
            repeat = OxmlElement('w:tblHeader'); trPr.append(repeat)
        for ci, cell in enumerate(row.cells):
            cell.width = Inches(widths[ci])
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cpr = cell._tc.get_or_add_tcPr()
            margins = OxmlElement('w:tcMar')
            for side in ('top','left','bottom','right'):
                e = OxmlElement('w:'+side); e.set(qn('w:w'),'95' if side in ('top','bottom') else '110'); e.set(qn('w:type'),'dxa'); margins.append(e)
            cpr.append(margins)
            if ri == 0:
                shade = OxmlElement('w:shd'); shade.set(qn('w:fill'),'E7E7E7'); cpr.append(shade)
            for p in cell.paragraphs:
                p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.05
                for r in p.runs:
                    set_font(r, 9.5, ri == 0)

def figure(doc, b):
    asset = BASE / b['asset']
    if not asset.exists():
        raise FileNotFoundError(asset)
    im = Image.open(asset)
    if asset.suffix.lower() == '.webp':
        converted = QA / (asset.stem + '.png')
        im.convert('RGB').save(converted)
        asset = converted
    width, height = im.size
    scale = min(b['max_width']/width, b['max_height']/height)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(); r.add_picture(str(asset), width=Inches(width*scale), height=Inches(height*scale))
    for dp in r._r.xpath('.//wp:docPr'):
        dp.set('descr', b['alt']); dp.set('title', asset.stem.replace('-',' '))
    p = doc.add_paragraph(b['caption'], style='Caption')
    p.paragraph_format.space_after = Pt(11)

def build():
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5); section.page_height = Inches(11)
    section.top_margin = Inches(.67); section.bottom_margin = Inches(.67)
    section.left_margin = Inches(.72); section.right_margin = Inches(.72)
    section.footer_distance = Inches(.28)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3','Caption']:
        s = doc.styles[name]; s.font.name = 'Arial'; s.font.color.rgb = RGBColor(0,0,0)
        if s._element.rPr is not None:
            for color in s._element.rPr.findall(qn('w:color')):
                for attr in ('themeColor','themeTint','themeShade'):
                    color.attrib.pop(qn('w:'+attr),None)
    # The stock Word template may give Title an inherited blue bottom border.
    # Remove borders from every paragraph style rather than hiding it with color.
    for s in doc.styles:
        if s._element.pPr is not None:
            for e in list(s._element.pPr.findall(qn('w:pBdr'))):
                s._element.pPr.remove(e)
    normal = doc.styles['Normal']; normal.font.size = Pt(11)
    normal.paragraph_format.line_spacing = 1.13
    normal.paragraph_format.space_after = Pt(8)
    title = doc.styles['Title']; title.font.size=Pt(29); title.font.bold=True
    title.paragraph_format.space_after=Pt(10)
    subtitle=doc.styles['Subtitle']; subtitle.font.size=Pt(15); subtitle.font.italic=False; subtitle.paragraph_format.space_after=Pt(10)
    h1=doc.styles['Heading 1']; h1.font.size=Pt(23); h1.font.bold=True
    h1.paragraph_format.space_before=Pt(0); h1.paragraph_format.space_after=Pt(14)
    h2=doc.styles['Heading 2']; h2.font.size=Pt(14); h2.font.bold=True
    h2.paragraph_format.space_before=Pt(10); h2.paragraph_format.space_after=Pt(6)
    cap=doc.styles['Caption']; cap.font.size=Pt(8.5); cap.font.italic=False; cap.font.bold=False
    cap.paragraph_format.line_spacing=1.08
    footer=section.footer.paragraphs[0]
    footer.paragraph_format.tab_stops.clear_all()
    footer.paragraph_format.tab_stops.add_tab_stop(Inches(7.02), WD_TAB_ALIGNMENT.RIGHT)
    set_font(footer.add_run('Priyam Sameer   UrbanKhet\t'),8)
    fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)
    doc.core_properties.title=CONTENT['title']; doc.core_properties.author=CONTENT['author']
    doc.core_properties.subject=CONTENT['purpose']
    doc.core_properties.keywords='UrbanKhet, Priyam Sameer, founder, agriculture, supply chain, portfolio'
    for pi,page in enumerate(CONTENT['pages']):
        if pi:
            doc.add_page_break()
        doc.add_paragraph(page['heading'], style='Title' if pi == 0 else 'Heading 1')
        for b in page['blocks']:
            typ=b['type']
            if typ=='p':
                doc.add_paragraph(b['text'])
            elif typ=='subtitle':
                doc.add_paragraph(b['text'],style='Subtitle')
            elif typ=='byline':
                p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(13);set_font(p.add_run(b['text']),10.2,True)
            elif typ=='h2':
                doc.add_paragraph(b['text'],style='Heading 2')
            elif typ=='small':
                p=doc.add_paragraph();p.paragraph_format.line_spacing=1.05;p.paragraph_format.space_after=Pt(7);set_font(p.add_run(b['text']),8.7)
            elif typ=='table':
                table=doc.add_table(rows=1,cols=len(b['headers']))
                for c,t in zip(table.rows[0].cells,b['headers']):c.text=t
                for row in b['rows']:
                    for c,t in zip(table.add_row().cells,row):c.text=t
                style_table(table,b['widths'])
                p=doc.add_paragraph();p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0);p.paragraph_format.line_spacing=.5;set_font(p.add_run(''),3)
            elif typ=='figure':
                figure(doc,b)
            elif typ=='source':
                p=doc.add_paragraph();p.paragraph_format.space_after=Pt(4);p.paragraph_format.line_spacing=1.0
                set_font(p.add_run(f"[{b['number']}] "),8.8)
                hyperlink(p,b['label'],b['url'],8.8)
                set_font(p.add_run('. '+b['note']),8.8)
                for r in p.runs:set_font(r,8.8)
            elif typ=='link':
                p=doc.add_paragraph();p.paragraph_format.space_after=Pt(3);p.paragraph_format.line_spacing=1.0
                hyperlink(p,b['label'],b['url'],9)
    doc.save(OUT)
    shutil.copy2(OUT,BASE/OUT.name)
    (BASE/'source'/'document-content.json').write_text(json.dumps(CONTENT,indent=2),encoding='utf-8')
    text=[]
    for p in CONTENT['pages']:
        text.append(p['heading'])
        for b in p['blocks']:
            text.append(b.get('text',b.get('caption',b.get('label',''))))
            text.extend(b.get('headers',[]))
            text.extend(c for r in b.get('rows',[]) for c in r)
            if 'note' in b:text.append(b['note'])
    count=len(re.findall(r"\b[\w]+(?:['’-][\w]+)*\b",' '.join(text)))
    print(json.dumps({'docx':str(OUT),'page_design_count':len(CONTENT['pages']),'word_count_excluding_image_text':count}))

if __name__=='__main__':
    build()
